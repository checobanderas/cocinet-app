import sys
import os
import subprocess
import importlib
import json

# ─── Directorio base ───────────────────────────────────────────────
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# ─── Dependencias ──────────────────────────────────────────────────
REQUIRED_PACKAGES = {
    "flask": "Flask",
    "flask_cors": "flask-cors",
    "flask_sock": "flask-sock",
    "win32print": "pywin32",
    "win32serviceutil": "pywin32",
    "PIL": "Pillow",
}

def ensure_deps():
    missing = []
    for module, package in REQUIRED_PACKAGES.items():
        try:
            importlib.import_module(module)
        except ImportError:
            if package not in missing:
                missing.append(package)
    if missing:
        print(f"Instalando dependencias faltantes: {missing}")
        for pkg in missing:
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
            except Exception as e:
                print(f"Error instalando {pkg}: {e}")

service_commands = {"install", "remove", "start", "stop", "restart", "debug", "update"}
running_as_service_cmd = len(sys.argv) > 1 and sys.argv[1].lower() in service_commands
if not running_as_service_cmd or sys.argv[1].lower() == "debug":
    ensure_deps()

# ─── Importaciones Seguras ─────────────────────────────────────────
import urllib.parse
import threading
import queue
import logging
from logging.handlers import RotatingFileHandler
import hashlib
import time
import sqlite3
import re
from datetime import datetime, timedelta

import win32print
import win32serviceutil
import win32service
import win32event
import servicemanager
import socket

# Importaciones para renderizado GDI
import win32ui
import win32con

# PIL
try:
    from PIL import Image, ImageWin
except ImportError:
    pass

from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from flask_sock import Sock

# ─── Configuración ─────────────────────────────────────────────────
PORT    = 3010
VERSION = "7.0.0-PRO"

# MODO DE IMPRESIÓN PREDETERMINADO: "hybrid" (Comandas en ESC/POS rápido, Cuentas en GDI), "raw" o "gdi"
PRINT_MODE = "hybrid"

# ─── Logging Rotativo & Registro de Caídas (Crash Log) ──────────────
LOG_FILE = os.path.join(BASE_DIR, "sentinel_printer.log")
CRASH_LOG_FILE = os.path.join(BASE_DIR, "sentinel_crash.log")
PROCESOSPICO_LOG_FILE = os.path.join(BASE_DIR, "procesospico.log")
PROCESOSPICO_ROOT_FILE = os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "procesospico.log")
pico_lock = threading.Lock()

def log_proceso_pico(source: str, tipo: str, operacion: str, duracion_ms: float, status: str = "OK", detalles: dict = None):
    """
    Registra mediciones de rendimiento de alta precisión en procesospico.log.
    Formato: [YYYY-MM-DD HH:MM:SS.mmm] [SOURCE] [TIPO] op="operacion" duracion=XX.XXms status=OK/ERROR detalles={...}
    """
    try:
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        det_str = f" {json.dumps(detalles, ensure_ascii=False)}" if detalles else ""
        line = f"[{timestamp}] [{source}] [{tipo}] op=\"{operacion}\" duracion={duracion_ms:.2f}ms status={status}{det_str}\n"
        
        with pico_lock:
            for target_path in [PROCESOSPICO_LOG_FILE, PROCESOSPICO_ROOT_FILE]:
                try:
                    with open(target_path, "a", encoding="utf-8") as f:
                        f.write(line)
                except Exception:
                    pass
    except Exception as e:
        print(f"Error registrando en procesospico.log: {e}")

def write_crash_log(event_type: str, message: str, details: str = ""):
    """Registra detalladamente la causa de caídas, errores o fallos en sentinel_crash.log."""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = (
            f"========================================================================\n"
            f"[{timestamp}] [CRASH / ERROR: {event_type}]\n"
            f"MENSAJE: {message}\n"
        )
        if details:
            entry += f"TRAZA DETALLADA:\n{details}\n"
        entry += "========================================================================\n\n"
        with open(CRASH_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception as e:
        print(f"Error escribiendo en crash log: {e}")

def get_logger():
    logger = logging.getLogger("sentinel")
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")
    
    # Manejador con rotación automática (Máximo 5MB por archivo, conserva 3 respaldos)
    fh = RotatingFileHandler(LOG_FILE, maxBytes=5*1024*1024, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    
    if sys.stdout and sys.stdout.isatty():
        ch = logging.StreamHandler(sys.stdout)
        ch.setFormatter(fmt)
        logger.addHandler(ch)
    return logger

log = get_logger()

# ─── Flask App & WebSockets (Puerto 3010) ─────────────────────────
app = Flask(__name__)
CORS(app)
sock = Sock(app)

app.logger.disabled = True
log_flask = logging.getLogger("werkzeug")
log_flask.setLevel(logging.ERROR)

@app.before_request
def pico_before_request():
    request._pico_start = time.perf_counter()

@app.after_request
def pico_after_request(response):
    if hasattr(request, "_pico_start") and request.path != "/api/log-procesopico":
        duration_ms = (time.perf_counter() - request._pico_start) * 1000.0
        status_str = "OK" if response.status_code < 400 else f"HTTP_{response.status_code}"
        log_proceso_pico(
            source="BACKEND_FLASK",
            tipo="ENDPOINT",
            operacion=f"{request.method} {request.path}",
            duracion_ms=duration_ms,
            status=status_str,
            detalles={"status_code": response.status_code, "client_ip": request.remote_addr}
        )
    return response

ws_clients = set()
ws_lock = threading.Lock()

def notify_step(step_code: str, message: str, status: str = "INFO", extra_data: dict = None):
    """
    Guarda el evento en sentinel_printer.log y transmite la traza paso a paso
    en tiempo real a través de WebSockets para la etapa de pruebas.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payload = {
        "timestamp": timestamp,
        "step": step_code,
        "message": message,
        "status": status,
        "data": extra_data or {}
    }
    
    log_msg = f"[{step_code}] [{status}] {message}"
    if extra_data:
        log_msg += f" | {json.dumps(extra_data, ensure_ascii=False)}"
        
    if status == "ERROR":
        log.error(log_msg)
        write_crash_log(step_code, message, json.dumps(extra_data, ensure_ascii=False) if extra_data else "")
    elif status == "WARNING":
        log.warning(log_msg)
    else:
        log.info(log_msg)

    # Broadcast a clientes WebSockets conectados
    dead_clients = set()
    with ws_lock:
        for client in list(ws_clients):
            try:
                client.send(json.dumps(payload, ensure_ascii=False))
            except Exception:
                dead_clients.add(client)
        ws_clients.difference_update(dead_clients)

@sock.route('/ws')
def websocket_endpoint(ws):
    """Endpoint WebSocket bidireccional: ws://localhost:3010/ws"""
    with ws_lock:
        ws_clients.add(ws)
    notify_step("WS_CONNECT", "Cliente conectado al socket de monitoreo", status="INFO")
    try:
        while True:
            raw_msg = ws.receive()
            if raw_msg:
                try:
                    data = json.loads(raw_msg)
                    if data.get("action") == "ping":
                        ws.send(json.dumps({
                            "action": "pong",
                            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        }))
                    elif data.get("action") == "echo":
                        notify_step("WS_ECHO", f"Prueba bidireccional recibida: {data.get('payload')}")
                except Exception as ex:
                    notify_step("WS_ERROR", f"Error procesando mensaje WS entrante: {ex}", status="WARNING")
    except Exception:
        pass
    finally:
        with ws_lock:
            ws_clients.discard(ws)
        notify_step("WS_DISCONNECT", "Cliente desconectado del socket de monitoreo", status="INFO")

# ─── Helpers Pro: Total en Letra & Detección de Emojis ──────────────────────
def numero_a_letras(monto: float) -> str:
    """Convierte un monto numérico en su representación formal de texto en español (pesos mexicanos M.N.)."""
    try:
        monto = round(float(monto), 2)
        entero = int(monto)
        centavos = int(round((monto - entero) * 100))

        UNIDADES = ["", "UN", "DOS", "TRES", "CUATRO", "CINCO", "SEIS", "SIETE", "OCHO", "NUEVE"]
        DECENAS = ["", "DIEZ", "VEINTE", "TREINTA", "CUARENTA", "CINCUENTA", "SESENTA", "SETENTA", "OCHENTA", "NOVENTA"]
        DIEZ_A_DIECINUEVE = ["DIEZ", "ONCE", "DOCE", "TRECE", "CATORCE", "QUINCE", "DIECISEIS", "DIECISIETE", "DIECIOCHO", "DIECINUEVE"]
        CENTENAS = ["", "CIENTO", "DOSCIENTOS", "TRESCIENTOS", "CUATROCIENTOS", "QUINIENTOS", "SEISCIENTOS", "SETECIENTOS", "OCHOCIENTOS", "NOVECIENTOS"]

        def _convertir_grupo(n):
            if n == 0:
                return ""
            if n == 100:
                return "CIEN"
            c = n // 100
            d = (n % 100) // 10
            u = n % 10
            texto = CENTENAS[c]
            res_d = ""
            if d == 1:
                res_d = DIEZ_A_DIECINUEVE[u]
            elif d == 2:
                if u == 0: res_d = "VEINTE"
                else: res_d = f"VEINTI{UNIDADES[u]}"
            elif d > 2:
                if u == 0: res_d = DECENAS[d]
                else: res_d = f"{DECENAS[d]} Y {UNIDADES[u]}"
            elif u > 0:
                res_d = UNIDADES[u]

            if texto and res_d:
                return f"{texto} {res_d}"
            return texto or res_d

        if entero == 0:
            texto_entero = "CERO"
        else:
            partes = []
            millones = entero // 1_000_000
            resto = entero % 1_000_000
            miles = resto // 1_000
            unidades = resto % 1_000

            if millones > 0:
                if millones == 1:
                    partes.append("UN MILLON")
                else:
                    partes.append(f"{_convertir_grupo(millones)} MILLONES")
            if miles > 0:
                if miles == 1:
                    partes.append("UN MIL")
                else:
                    partes.append(f"{_convertir_grupo(miles)} MIL")
            if unidades > 0:
                partes.append(_convertir_grupo(unidades))

            texto_entero = " ".join(partes)

        moneda = "PESO" if entero == 1 else "PESOS"
        return f"SON: ({texto_entero} {moneda} {centavos:02d}/100 M.N.)"
    except Exception:
        return ""

def has_emoji(text: str) -> bool:
    """Detecta si el texto contiene caracteres Emojis Unicode."""
    for char in text:
        code = ord(char)
        if (0x1F300 <= code <= 0x1F9FF) or (0x2600 <= code <= 0x27BF) or (0x1F600 <= code <= 0x1F64F) or (0x1F680 <= code <= 0x1F6FF):
            return True
    return False

# ─── Configuración de Impresoras y Tamaños de Papel ────────────────────────────
CONFIG_FILE = os.path.join(BASE_DIR, "printer_config.json")

def load_printer_config():
    default_config = {
        "PRINT_MODE": "hybrid",
        "PRINTER_MAP": {
            "cuentas": "CUENTAS",
            "cocina":  "COCINA",
            "barra":   "BARRA",
        },
        "PRINTER_PAPER_SIZES": {
            "cuentas": "80mm",
            "cocina":  "80mm",
            "barra":   "80mm",
        },
        "LOGO_PATH": "logo.png",
        "FONT_NAME": "Segoe UI",
        "FONT_SIZE_PT": 11.0,
        "HEADER_FONT_SIZE_PT": 16.0,
        "ITEM_FONT_SIZE_PT": 11.0,
        "TOTAL_FONT_SIZE_PT": 15.0,
        "MARGIN_LEFT_PX": 10,
        "MARGIN_RIGHT_PX": 25,
        "LINE_SPACING": 4,
        "SHOW_DIVIDER": True,
        "COMANDAS_MODO": "ESC/POS",
        "COMANDAS_TAMANO_ENCABEZADO": "DOBLE_ALTO_Y_ANCHO",
        "COMANDAS_TAMANO_PLATILLOS": "2x2",
        "COMANDAS_NOTAS_RESALTADAS": True,
        "BACKUP_FOLDER": "C:\\buzon\\respaldos"
    }
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict):
                    default_config.update(data)
                if "PRINT_MODE" in data:
                    default_config["PRINT_MODE"] = str(data["PRINT_MODE"]).strip().lower()
                if "PRINTER_MAP" in data and isinstance(data["PRINTER_MAP"], dict):
                    default_config["PRINTER_MAP"].update(data["PRINTER_MAP"])
                if "PRINTER_PAPER_SIZES" in data and isinstance(data["PRINTER_PAPER_SIZES"], dict):
                    default_config["PRINTER_PAPER_SIZES"].update(data["PRINTER_PAPER_SIZES"])
                if "FONT_SIZE_PT" in data:
                    default_config["FONT_SIZE_PT"] = float(data["FONT_SIZE_PT"])
                if "HEADER_FONT_SIZE_PT" in data:
                    default_config["HEADER_FONT_SIZE_PT"] = float(data["HEADER_FONT_SIZE_PT"])
                if "ITEM_FONT_SIZE_PT" in data:
                    default_config["ITEM_FONT_SIZE_PT"] = float(data["ITEM_FONT_SIZE_PT"])
                if "TOTAL_FONT_SIZE_PT" in data:
                    default_config["TOTAL_FONT_SIZE_PT"] = float(data["TOTAL_FONT_SIZE_PT"])
                if "MARGIN_LEFT_PX" in data:
                    default_config["MARGIN_LEFT_PX"] = int(data["MARGIN_LEFT_PX"])
                if "MARGIN_RIGHT_PX" in data:
                    default_config["MARGIN_RIGHT_PX"] = int(data["MARGIN_RIGHT_PX"])
                if "LINE_SPACING" in data:
                    default_config["LINE_SPACING"] = int(data["LINE_SPACING"])
                if "SHOW_DIVIDER" in data:
                    default_config["SHOW_DIVIDER"] = bool(data["SHOW_DIVIDER"])
        except Exception as e:
            log.error(f"Error cargando config de impresoras: {e}")
    else:
        try:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(default_config, f, indent=4, ensure_ascii=False)
        except Exception:
            pass
    return default_config

def save_printer_config(new_config: dict) -> dict:
    global PRINTER_MAP, PRINTER_PAPER_SIZES, LOGO_PATH, FONT_NAME, FONT_SIZE_PT, BACKUP_FOLDER
    current = load_printer_config()
    current.update(new_config)

    # Rutas sincronizadas para que todos los procesos lean la misma configuración
    target_files = [
        CONFIG_FILE,
        os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "printer_config.json"),
        os.path.join(os.path.dirname(BASE_DIR), "printer_config.json"),
        os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "dist", "printer_config.json"),
    ]

    for tf in target_files:
        try:
            os.makedirs(os.path.dirname(tf), exist_ok=True)
            with open(tf, "w", encoding="utf-8") as f:
                json.dump(current, f, indent=4, ensure_ascii=False)
        except Exception:
            pass

    PRINTER_MAP = current.get("PRINTER_MAP", {})
    PRINTER_PAPER_SIZES = current.get("PRINTER_PAPER_SIZES", {})
    LOGO_PATH = current.get("LOGO_PATH", "logo.png")
    FONT_NAME = current.get("FONT_NAME", "Segoe UI")
    FONT_SIZE_PT = float(current.get("FONT_SIZE_PT", 11.0))
    BACKUP_FOLDER = current.get("BACKUP_FOLDER", "C:\\buzon\\respaldos")
    return current

config_printers = load_printer_config()
PRINTER_MAP = config_printers["PRINTER_MAP"]
PRINTER_PAPER_SIZES = config_printers["PRINTER_PAPER_SIZES"]
LOGO_PATH = config_printers["LOGO_PATH"]
FONT_NAME = config_printers["FONT_NAME"]
FONT_SIZE_PT = config_printers["FONT_SIZE_PT"]
BACKUP_FOLDER = config_printers.get("BACKUP_FOLDER", "C:\\buzon\\respaldos")

def sanitize_text(text: str) -> str:
    """Remueve cualquier caracter de control binario residual de ESC/POS (como \x1b, \x1d, LE1, E1, etc.)."""
    if not text:
        return ""
    text = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', text)
    text = re.sub(r'(?:LE[01]|E[01]|!\d+)', '', text)
    text = re.sub(r'^a(?=[A-Z0-9\(\$])', '', text)
    text = re.sub(r'(?<=[0-9\)\w])a{1,3}$', '', text)
    return text.strip()

# ─── Parser de Comandos ESC/POS ───────────────────────────────────
def parse_escpos(raw_bytes: bytes) -> list:
    """
    Decodifica un flujo de bytes ESC/POS y lo convierte en una lista de líneas estructuradas
    con propiedades de alineación, tamaño de fuente y negritas para su renderizado GDI.
    """
    lines = []
    current_line_text = ""
    
    align = 0  # 0=izq, 1=centro, 2=der
    bold = False
    size = 'normal'  # 'normal', 'big', 'small'

    def flush_current():
        nonlocal current_line_text
        if current_line_text.strip():
            lines.append({
                'text': current_line_text.strip(),
                'align': align,
                'size': size,
                'bold': bold
            })
            current_line_text = ""
    
    i = 0
    n = len(raw_bytes)
    
    while i < n:
        b = raw_bytes[i]
        
        # Comando ESC (0x1b / 27)
        if b == 0x1b:
            if i + 1 < n:
                cmd = raw_bytes[i + 1]
                if cmd == 0x40:
                    flush_current()
                    align = 0
                    bold = False
                    size = 'normal'
                    i += 2
                    continue
                elif cmd == 0x61:
                    if i + 2 < n:
                        flush_current()
                        align = raw_bytes[i + 2]
                        i += 3
                        continue
                elif cmd == 0x21:
                    if i + 2 < n:
                        mode = raw_bytes[i + 2]
                        new_bold = bool(mode & 8)
                        new_size = 'big' if (mode & 48 or mode & 16 or mode & 32) else 'normal'
                        if new_bold != bold or new_size != size:
                            flush_current()
                            bold = new_bold
                            size = new_size
                        i += 3
                        continue
                elif cmd == 0x45:
                    if i + 2 < n:
                        new_bold = raw_bytes[i + 2] in (1, ord('1'), 0x01)
                        if new_bold != bold:
                            flush_current()
                            bold = new_bold
                        i += 3
                        continue
                elif cmd == 0x64:
                    if i + 2 < n:
                        feed_count = raw_bytes[i + 2]
                        flush_current()
                        for _ in range(max(1, feed_count - 1)):
                            lines.append({
                                'text': '',
                                'align': align,
                                'size': size,
                                'bold': bold
                            })
                        i += 3
                        continue
                elif cmd in (0x4a, 0x33, 0x32, 0x4d, 0x7b, 0x56):
                    i += 3
                    continue
            i += 2
            continue
            
        # Comando GS (0x1d / 29)
        elif b == 0x1d:
            if i + 1 < n:
                cmd = raw_bytes[i + 1]
                if cmd == 0x56:
                    if i + 2 < n and raw_bytes[i + 2] in (65, 66):
                        i += 4
                        continue
                    else:
                        i += 3
                        continue
                elif cmd == 0x21: # GS ! n -> Select character size
                    if i + 2 < n:
                        size_byte = raw_bytes[i + 2]
                        w_mult = (size_byte >> 4) & 0x07
                        h_mult = size_byte & 0x07
                        new_size = 'big' if (w_mult > 0 or h_mult > 0) else 'normal'
                        if new_size != size:
                            flush_current()
                            size = new_size
                        i += 3
                        continue
                elif cmd in (0x42, 0x6b, 0x77, 0x68):
                    i += 3
                    continue
            i += 2
            continue
            
        elif b == 0x0a:
            flush_current()
            i += 1
            
        elif b == 0x0d:
            if i + 1 < n and raw_bytes[i + 1] == 0x0a:
                i += 1
            else:
                flush_current()
                i += 1
            
        else:
            decoded = False
            for length in (4, 3, 2, 1):
                if i + length <= n:
                    try:
                        char_str = raw_bytes[i:i+length].decode('utf-8')
                        current_line_text += char_str
                        i += length
                        decoded = True
                        break
                    except UnicodeDecodeError:
                        continue
            if not decoded:
                try:
                    char_str = raw_bytes[i:i+1].decode('cp850')
                except Exception:
                    char_str = chr(b)
                current_line_text += char_str
                i += 1
            
    flush_current()
        
    cleaned_lines = []
    for l in lines:
        cleaned_text = sanitize_text(l['text'])
        if cleaned_text or l['text'] == '':
            cleaned_lines.append({**l, 'text': cleaned_text})

    return cleaned_lines

# ─── Motores de Impresión ─────────────────────────────────────────
_installed_printers_cache = []
_installed_printers_cache_time = 0

def get_installed_printers(force_refresh: bool = False) -> list:
    global _installed_printers_cache, _installed_printers_cache_time
    now = time.time()
    if not force_refresh and _installed_printers_cache and (now - _installed_printers_cache_time < 60):
        return _installed_printers_cache
    try:
        flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
        _installed_printers_cache = [p[2] for p in win32print.EnumPrinters(flags)]
        _installed_printers_cache_time = now
    except Exception as e:
        log.warning(f"Error enumerando impresoras: {e}")
        if not _installed_printers_cache:
            _installed_printers_cache = []
    return _installed_printers_cache

def resolve_printer_name(key: str) -> str:
    global PRINTER_MAP
    try:
        config_printers = load_printer_config()
        PRINTER_MAP = config_printers.get("PRINTER_MAP", PRINTER_MAP)
    except Exception:
        pass
        
    target = PRINTER_MAP.get(key.lower(), key)
    installed = get_installed_printers()
    if not installed:
        return target or key
        
    for p in installed:
        if p.upper() == target.upper():
            return p
            
    for p in installed:
        if target.upper() in p.upper() or p.upper() in target.upper():
            return p
            
    try:
        default_win = win32print.GetDefaultPrinter()
        if default_win in installed:
            notify_step("PRINTER_WARN", f"Impresora '{target}' no mapeada. Usando predeterminada: '{default_win}'", status="WARNING")
            return default_win
    except Exception:
        pass
        
    first_printer = installed[0]
    notify_step("PRINTER_WARN", f"Impresora '{target}' no encontrada. Usando primera disponible: '{first_printer}'", status="WARNING")
    return first_printer

def send_raw_to_printer(printer_name: str, data_bytes: bytes):
    notify_step("3_PRINT_RAW", f"Enviando bytes RAW al spooler de Windows para [{printer_name}]", status="INFO")
    hPrinter = win32print.OpenPrinter(printer_name)
    try:
        job_name = f"COCINET-RAW-{datetime.now().strftime('%H%M%S')}"
        win32print.StartDocPrinter(hPrinter, 1, (job_name, None, "RAW"))
        try:
            win32print.StartPagePrinter(hPrinter)
            win32print.WritePrinter(hPrinter, data_bytes)
            win32print.EndPagePrinter(hPrinter)
        finally:
            win32print.EndDocPrinter(hPrinter)
    finally:
        win32print.ClosePrinter(hPrinter)

def draw_logo_on_dc(hDC, logo_path: str, printable_width: int, y_start: int, dpi_y: int, full_width: int = None) -> int:
    if not logo_path:
        return y_start
    
    target_path = logo_path if os.path.isabs(logo_path) else os.path.join(BASE_DIR, logo_path)
    if not os.path.exists(target_path):
        alt_paths = [
            os.path.join("C:\\buzon", os.path.basename(logo_path)),
            os.path.join(BASE_DIR, "logoroy.png"),
            os.path.join(BASE_DIR, "logo.png"),
            os.path.join("C:\\buzon", "logoroy.png")
        ]
        found = False
        for alt in alt_paths:
            if os.path.exists(alt):
                target_path = alt
                found = True
                break
        if not found:
            notify_step("LOGO_WARN", f"Archivo de logo no encontrado en: {logo_path}", status="WARNING")
            return y_start

    try:
        from PIL import Image, ImageWin
        img = Image.open(target_path)
        if img.mode != "RGB":
            img = img.convert("RGB")
            
        w, h = img.size
        page_width = full_width if full_width else printable_width
        max_logo_width = int(page_width * 0.45)
        scale = max_logo_width / float(w)
        new_w = max_logo_width
        new_h = int(h * scale)
        
        img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
        x_start = (page_width - new_w) // 2
        
        hdc_handle = hDC.GetSafeHdc()
        dib = ImageWin.Dib(img)
        dib.draw(hdc_handle, (x_start, y_start, x_start + new_w, y_start + new_h))
        return y_start + new_h + 15
    except Exception as e:
        notify_step("LOGO_ERROR", f"Error renderizando el logotipo GDI ({target_path}): {e}", status="WARNING")
        return y_start

def wrap_and_draw_text(hDC, text: str, margin_left: int, margin_right: int, printable_width: int, y: int, align: int = 0, line_spacing: int = 4) -> int:
    if not text:
        return y
        
    text_w, text_h = hDC.GetTextExtent(text)
    if text_w <= printable_width:
        if align == 1:
            x = margin_left + (printable_width - text_w) // 2
        elif align == 2:
            x = margin_left + printable_width - text_w
        else:
            x = margin_left
        hDC.TextOut(x, y, text)
        return y + text_h + line_spacing

    words = text.split(" ")
    lines_to_draw = []
    curr_line = ""
    
    for word in words:
        test_line = f"{curr_line} {word}".strip() if curr_line else word
        w, _ = hDC.GetTextExtent(test_line)
        if w <= printable_width:
            curr_line = test_line
        else:
            if curr_line:
                lines_to_draw.append(curr_line)
            w_word, _ = hDC.GetTextExtent(word)
            if w_word > printable_width:
                sub = ""
                for char in word:
                    if hDC.GetTextExtent(sub + char)[0] <= printable_width:
                        sub += char
                    else:
                        lines_to_draw.append(sub)
                        sub = char
                curr_line = sub
            else:
                curr_line = word
                
    if curr_line:
        lines_to_draw.append(curr_line)
        
    for l_text in lines_to_draw:
        tw, th = hDC.GetTextExtent(l_text)
        if align == 1:
            x = margin_left + (printable_width - tw) // 2
        elif align == 2:
            x = margin_left + printable_width - tw
        else:
            x = margin_left
        hDC.TextOut(x, y, l_text)
        y += th + line_spacing
        
    return y

def send_gdi_to_printer(printer_name: str, data_bytes: bytes, ticket_type: str = "comanda"):
    global PRINTER_MAP, PRINTER_PAPER_SIZES, LOGO_PATH, FONT_NAME, FONT_SIZE_PT
    config_printers = load_printer_config()
    PRINTER_MAP = config_printers["PRINTER_MAP"]
    PRINTER_PAPER_SIZES = config_printers["PRINTER_PAPER_SIZES"]
    LOGO_PATH = config_printers["LOGO_PATH"]
    FONT_NAME = config_printers["FONT_NAME"]
    FONT_SIZE_PT = config_printers["FONT_SIZE_PT"]

    notify_step("2_PROCESS_GDI", f"Parseando comandos ESC/POS para renderizado GDI en [{printer_name}]", status="INFO")
    parsed_lines = parse_escpos(data_bytes)
    notify_step("PARSED_LINES_DEBUG", f"Total parsed_lines: {len(parsed_lines)}", extra_data={"texts": [l['text'] for l in parsed_lines if l['text']]})
    
    printer_key = "cuentas"
    if ticket_type and ticket_type.lower() in PRINTER_PAPER_SIZES:
        printer_key = ticket_type.lower()
    else:
        for k, v in PRINTER_MAP.items():
            if v.upper() == printer_name.upper():
                printer_key = k
                break
            
    paper_size = PRINTER_PAPER_SIZES.get(printer_key, "80mm")
    
    hDC = win32ui.CreateDC()
    hDC.CreatePrinterDC(printer_name)
    hDC.SetMapMode(win32con.MM_TEXT)
    hDC.SetBkMode(win32con.TRANSPARENT)
    
    dpi_y = hDC.GetDeviceCaps(win32con.LOGPIXELSY) or 203
    
    dev_width = hDC.GetDeviceCaps(win32con.HORZRES) or hDC.GetDeviceCaps(win32con.PHYSICALWIDTH)
    if paper_size == "58mm":
        width = dev_width if (dev_width and 250 <= dev_width <= 420) else 370
        margin_left = 10
        margin_right = 10
    else: # 80mm default
        width = dev_width if (dev_width and dev_width >= 500) else 560
        margin_left = 15
        margin_right = 15

    printable_width = width - margin_left - margin_right
    job_name = f"COCINET-GDI-{paper_size}-{datetime.now().strftime('%H%M%S')}"
    
    notify_step("3_PRINT_GDI_SPOOL", f"Iniciando documento vectorial GDI en [{printer_name}] ({paper_size})", status="INFO")
    try:
        hDC.StartDoc(job_name)
        hDC.StartPage()
        
        font_cache = {}
        pen_cache = {}
        last_drawn_line_y = -999

        def get_font(name, pt_size, is_bold, is_italic=False, use_emoji_font=False):
            font_name_to_use = "Segoe UI Emoji" if (use_emoji_font or name == "Segoe UI Emoji") else name
            key = (font_name_to_use, pt_size, is_bold, is_italic)
            if key in font_cache:
                return font_cache[key]
            height = int(pt_size * dpi_y / 72)
            f = win32ui.CreateFont({
                "name": font_name_to_use,
                "height": height,
                "weight": win32con.FW_BOLD if is_bold else win32con.FW_NORMAL,
                "italic": is_italic,
                "charset": win32con.DEFAULT_CHARSET
            })
            font_cache[key] = f
            return f

        def get_pen(width=2, color=0):
            key = (win32con.PS_SOLID, width, color)
            if key in pen_cache:
                return pen_cache[key]
            p = win32ui.CreatePen(win32con.PS_SOLID, width, color)
            pen_cache[key] = p
            return p

        def draw_solid_line(y_pos):
            nonlocal last_drawn_line_y
            if abs(y_pos - last_drawn_line_y) > 6:
                hDC.SelectObject(get_pen(2, 0))
                hDC.MoveTo(margin_left, y_pos)
                hDC.LineTo(width - margin_right, y_pos)
                last_drawn_line_y = y_pos
                return y_pos + 8
            return y_pos

        y = 20
        
        if ticket_type.lower() not in ["cocina", "barra"]:
            y = draw_logo_on_dc(hDC, LOGO_PATH, printable_width, y, dpi_y, full_width=width)
        
        base_pt = FONT_SIZE_PT
        if paper_size == "58mm":
            base_pt = base_pt * 0.82
            
        expanded_lines = []
        for l in parsed_lines:
            txt = l['text'].strip()
            if not txt:
                expanded_lines.append(l)
                continue
                
            # Un-stick glued fiscal field headers
            txt = re.sub(
                r'([A-Z0-9])(RFC|REGIMEN|RÉGIMEN|LUGAR|DIR|SUC|SUCURSAL|TEL|TELEFONO|TELÉFONO|METODO|MÉTODO|FORMA|PAGO)\b',
                r'\1\n\2',
                txt,
                flags=re.IGNORECASE
            )

            # Un-stick dashes/underscores/equals glued to text
            txt = re.sub(r'([^\-\_\=\s])([\-\_\=]{3,})', r'\1\n\2', txt)
            txt = re.sub(r'([\-\_\=]{3,})([^\-\_\=\s])', r'\1\n\2', txt)
            
            # Split text by newlines into clean individual lines
            sub_lines = txt.split('\n')
            for sl in sub_lines:
                sl_clean = sl.strip()
                if not sl_clean:
                    continue
                item_split_pattern = r'(\d+\s*(?:x|X)\s+.*?(?:\$?[0-9]+(?:\.[0-9]{1,2})?)(?=\s*\d+\s*(?:x|X)\s+|$))'
                found_items = re.findall(item_split_pattern, sl_clean, flags=re.IGNORECASE)
                if len(found_items) > 1:
                    for item_str in found_items:
                        if item_str.strip():
                            expanded_lines.append({**l, 'text': item_str.strip()})
                    continue

                keywords_pattern = r'(?=(?:RFC|REGIMEN|RÉGIMEN|LUGAR|DIR|SUC|SUCURSAL|FOLIO|REIMPRESION|PRECUENTA|MESA|FECHA|HORA|METODO|MÉTODO|FORMA|PAGO|SUBTOTAL|(?<!SUB)TOTAL|PROPINA|DESCUENTO|CAMBIO|TEL|TELÉFONO|TELEFONO)\s*:)'
                found_parts = re.split(keywords_pattern, sl_clean, flags=re.IGNORECASE)
                if len(found_parts) > 1:
                    combined_parts = []
                    curr_p = ""
                    for p in found_parts:
                        p_str = p.strip()
                        if not p_str:
                            continue
                        if curr_p and not re.search(r'[A-Za-z0-9]', curr_p):
                            curr_p = f"{curr_p} {p_str}".strip()
                        elif curr_p:
                            combined_parts.append(curr_p)
                            curr_p = p_str
                        else:
                            curr_p = p_str
                    if curr_p:
                        combined_parts.append(curr_p)

                    for p in combined_parts:
                        if p.strip():
                            expanded_lines.append({**l, 'text': p.strip()})
                else:
                    for sub_p in sl_clean.split('\n'):
                        if sub_p.strip():
                            expanded_lines.append({**l, 'text': sub_p.strip()})

        pending_total_amount = None
        header_drawn = False
        in_table_phase = False

        for line in expanded_lines:
            text = line['text'].strip()
            alignment = line['align']
            size_mode = line['size']
            is_bold = line['bold']
            line_has_emoji = has_emoji(text)
            
            # Omit payment line when payment is LUPAY
            if "LUPAY" in text.upper():
                continue

            if len(text) >= 6 and all(c in ('-', '=', '_', '*', ' ', '─', '━') for c in text):
                if pending_total_amount is not None:
                    try:
                        letra_str = numero_a_letras(pending_total_amount)
                        if letra_str:
                            f_letra = get_font(FONT_NAME, base_pt * 0.85, True, is_italic=True, use_emoji_font=has_emoji(letra_str))
                            hDC.SelectObject(f_letra)
                            y = wrap_and_draw_text(hDC, letra_str, margin_left, margin_right, printable_width, y, align=1, line_spacing=3)
                    except Exception:
                        pass
                    pending_total_amount = None
                y = draw_solid_line(y + 4)
                continue
                
            if not text:
                f = get_font(FONT_NAME, base_pt, False)
                hDC.SelectObject(f)
                _, text_height = hDC.GetTextExtent(" ")
                y += text_height
                continue

            clean_upper = re.sub(r'[\U00010000-\U0010ffff\u2600-\u27bf\u1f300-\u1f9ff]', '', text).strip().upper()
                
            if size_mode == 'big':
                pt = base_pt * 1.30
                bold_to_use = True
            elif size_mode == 'small':
                pt = base_pt * 0.75
                bold_to_use = is_bold
            else:
                pt = base_pt
                bold_to_use = is_bold
                
            f = get_font(FONT_NAME, pt, bold_to_use, use_emoji_font=line_has_emoji)
            hDC.SelectObject(f)

            HEADER_KEYS = [
                "MESA", "HORA", "FOLIO", "FECHA", "COMANDA", "SUBTOTAL", "TOTAL", 
                "PROPINA", "DESCUENTO", "PAGADO CON", "PAGADO", "PAGO CON", "PAGO", 
                "METODO DE PAGO", "MÉTODO DE PAGO", "METODO", "MÉTODO", "FORMA DE PAGO", "FORMA", 
                "DIR", "DIR FISCAL", "DIRECCION", "DIRECCIÓN", "TEL", "TELEFONO", "TELÉFONO", "CELULAR", 
                "CLIENTE", "ATENDIO", "MESERO", "REIMPRESION", "CUENTA", "PRECUENTA", 
                "SUC", "SUCURSAL", "RFC", "DATOS DE ENVIO", "SON", "EFECTIVO", "TARJETA", 
                "TRANSFERENCIA", "DESTINO", "GRACIAS", "VISITA", "VUELVA", "OBS", 
                "FACTURAR", "FACTURA", "REGIMEN", "RÉGIMEN", "REGIMEN FISCAL", "RÉGIMEN FISCAL",
                "LUGAR", "LUGAR EXPEDICION", "LUGAR DE EXPEDICIÓN", "C.P.", "CP"
            ]
            
            first_word = re.sub(r'[^A-Z]', '', clean_upper.split(':')[0]) if ':' in clean_upper else (re.sub(r'[^A-Z]', '', clean_upper.split()[0]) if clean_upper else "")
            is_header_keyword = any(first_word == k or first_word.startswith(k) for k in HEADER_KEYS)
            
            has_qty = bool(re.match(r'^\s*\d+\s*(?:x|X)\s+', text, re.IGNORECASE))
            has_price = bool(re.search(r'\$\s*[0-9]+(?:\.[0-9]{1,2})?\s*$', text)) or bool(re.search(r'\s+[0-9]+\.[0-9]{2}\s*$', text))
            
            is_item_line = bool(
                not is_header_keyword and
                (has_qty or (has_price and not any(k in clean_upper for k in ["C.P.", "CP", "TEL", "RFC", "FOLIO", "MESA", "HORA", "FECHA", "REGIMEN", "RÉGIMEN", "PAGO", "CAMBIO", "SUBTOTAL", "TOTAL", "SUC"]))) and
                not any(c in ('-', '=', '_', '*') for c in text)
            )

            if "DETALLE DEL PEDIDO" in clean_upper or "DETALLE DE PEDIDO" in clean_upper:
                if ticket_type.lower() not in ["cocina", "barra"] and not header_drawn:
                    header_drawn = True
                    in_table_phase = True
                    y += 4
                    f_section = get_font(FONT_NAME, base_pt * 1.05, True, use_emoji_font=True)
                    hDC.SelectObject(f_section)
                    sec_title = "📝 DETALLE DEL PEDIDO 📝"
                    w_st, h_st = hDC.GetTextExtent(sec_title)
                    x_st = max(margin_left, (width - w_st) // 2)
                    hDC.TextOut(x_st, y, sec_title)
                    y += h_st + 6

                    y = draw_solid_line(y + 2)
                    
                    fh = get_font(FONT_NAME, base_pt * 0.88, True)
                    hDC.SelectObject(fh)
                    hDC.TextOut(margin_left, y, "CANT / DESCRIPCIÓN")
                    w_imp, h_imp = hDC.GetTextExtent("IMPORTE")
                    x_imp = width - margin_right - w_imp
                    hDC.TextOut(x_imp, y, "IMPORTE")
                    y += h_imp + 4
                    
                    y = draw_solid_line(y + 2)
                continue

            if is_item_line and not header_drawn and ticket_type.lower() not in ["cocina", "barra"]:
                header_drawn = True
                in_table_phase = True
                
                y = draw_solid_line(y + 2)
                
                fh = get_font(FONT_NAME, base_pt * 0.88, True)
                hDC.SelectObject(fh)
                hDC.TextOut(margin_left, y, "CANT / DESCRIPCIÓN")
                w_imp, h_imp = hDC.GetTextExtent("IMPORTE")
                x_imp = width - margin_right - w_imp
                hDC.TextOut(x_imp, y, "IMPORTE")
                y += h_imp + 4
                
                y = draw_solid_line(y + 2)

            if not is_item_line and in_table_phase:
                in_table_phase = False
                y = draw_solid_line(y + 2)

            if is_item_line:
                desc = text.strip()
                price_str = None
                qty_str = None
                
                p_m = re.search(r'\$?([0-9]+(?:\.[0-9]{1,2})?)\s*$', desc)
                if p_m:
                    price_str = p_m.group(1)
                    desc = desc[:p_m.start()].strip()
                    
                q_m = re.match(r'^\s*(\d+)\s*(?:x|X)?\s+(.*)$', desc, re.IGNORECASE)
                if q_m:
                    qty_str = q_m.group(1)
                    desc = q_m.group(2).strip()
                    
                qty_val = int(qty_str) if (qty_str and qty_str.isdigit()) else 1
                price_num = float(price_str.replace(',', '')) if price_str else 0.0
                
                imp_str = f"${price_num:.2f}" if price_num > 0 else ""
                fp = get_font(FONT_NAME, pt * 0.95, True)
                hDC.SelectObject(fp)
                
                if imp_str:
                    pr_w, pr_h = hDC.GetTextExtent(imp_str)
                    x_right = max(margin_left + 120, width - margin_right - pr_w)
                    hDC.TextOut(x_right, y, imp_str)
                else:
                    pr_w, pr_h = 0, int(pt * dpi_y / 72)
                    x_right = width - margin_right
                    
                desc_w = width - margin_left - margin_right - (pr_w + 15 if imp_str else 0)
                prefix = f"{qty_val}  " if qty_str else ""
                full_desc = prefix + desc
                y = wrap_and_draw_text(hDC, full_desc, margin_left, margin_right, desc_w, y, align=0, line_spacing=2)
                y += 2
                continue
            
            if text.upper().startswith("MESA:") or text.upper().startswith("FOLIO:") or text.upper().startswith("CMD #") or "FOLIO INTERNO" in text.upper():
                f_mesa = get_font(FONT_NAME, base_pt * 1.30, True, use_emoji_font=line_has_emoji)
                hDC.SelectObject(f_mesa)
                y = wrap_and_draw_text(hDC, text, margin_left, margin_right, printable_width, y, align=alignment, line_spacing=4)
                continue

            if any(text.upper().startswith(k) for k in ["MESERO:", "ATENDIO:", "ATENDIÓ:", "ATENDIDO:", "ATENDIDO POR:"]):
                f_mesero = get_font(FONT_NAME, base_pt * 1.15, True, use_emoji_font=line_has_emoji)
                hDC.SelectObject(f_mesero)
                y = wrap_and_draw_text(hDC, text, margin_left, margin_right, printable_width, y, align=alignment, line_spacing=4)
                continue

            if text.upper().startswith("FECHA:") or text.upper().startswith("HORA:") or "FECHA:" in text.upper():
                clean_date_text = text
                if "FECHA:" in clean_date_text.upper():
                    date_val = re.sub(r'^FECHA:\s*', '', clean_date_text, flags=re.IGNORECASE).strip()
                    if ',' in date_val:
                        parts = date_val.split(',', 1)
                        f_part = parts[0].strip()
                        h_part = parts[1].strip()
                        formatted_dt = f"📅 {f_part}   ⏰ {h_part}"
                    else:
                        formatted_dt = f"📅 {date_val}"
                elif clean_date_text.upper().startswith("HORA:"):
                    hora_val = clean_date_text[5:].strip()
                    formatted_dt = f"⏰ {hora_val}"
                else:
                    formatted_dt = text

                f_dt = get_font(FONT_NAME, base_pt * 1.05, True, use_emoji_font=True)
                hDC.SelectObject(f_dt)
                y = wrap_and_draw_text(hDC, formatted_dt, margin_left, margin_right, printable_width, y, align=0, line_spacing=4)
                continue
            
            total_match = re.search(r'^(?:[^\w\s]+\s*)?(TOTAL A PAGAR|TOTAL|SUBTOTAL|SUMA TOTAL|PROPINA|DESCUENTO|PAGADO CON|PAGADO|PAGO CON|METODO DE PAGO|MÉTODO DE PAGO|FORMA DE PAGO|METODO|MÉTODO|PAGO|CAMBIO|FACTURAR|FACTURA)\s*:?\s*(.*)$', text, re.IGNORECASE)
            has_total_keyword = bool(total_match or "TOTAL" in text.upper() or "SUBTOTAL" in text.upper())
            
            if has_total_keyword:
                if "SUBTOTAL" in text.upper() or ("TOTAL" in text.upper() and not any(k in text.upper() for k in ["PAGADO", "CAMBIO", "PROPINA"])):
                    y = draw_solid_line(y + 2)

                if total_match:
                    match_keyword = total_match.group(1).upper()
                    val = total_match.group(2).strip()
                    if any(k in match_keyword for k in ["PAGADO CON", "PAGO CON"]):
                        label = "💵 PAGADO CON:"
                    elif "PAGADO" in match_keyword:
                        label = "💵 PAGADO CON:"
                    elif any(k in match_keyword for k in ["METODO", "MÉTODO", "FORMA", "PAGO"]):
                        clean_val = (val or match_keyword).upper()
                        if "DÉBITO" in clean_val or "DEBITO" in clean_val:
                            label = "💳 TARJETA DÉBITO"
                        elif "CRÉDITO" in clean_val or "CREDITO" in clean_val:
                            label = "💳 TARJETA CRÉDITO"
                        elif "EFECTIVO" in clean_val or "CASH" in clean_val:
                            label = "💵 EFECTIVO"
                        elif "TRANSFERENCIA" in clean_val or "TRANSFER" in clean_val:
                            label = "💸 TRANSFERENCIA"
                        elif "LUPAY" in clean_val:
                            label = "📲 LUPAY"
                        elif "TARJETA" in clean_val:
                            label = "💳 TARJETA"
                        elif clean_val and clean_val not in ["PAGO", "METODO", "MÉTODO"]:
                            label = f"💳 {clean_val}"
                        else:
                            label = "💳 TARJETA"
                        val = ""
                    elif "CAMBIO" in match_keyword:
                        label = "🪙 CAMBIO:"
                    elif "FACTURAR" in match_keyword or "FACTURA" in match_keyword:
                        label = "🧾 REQUIERE FACTURA"
                        val = ""
                    else:
                        label = match_keyword + ":"
                else:
                    parts = text.split(":", 1)
                    label = parts[0].strip().upper() + ":"
                    val = parts[1].strip() if len(parts) > 1 else ""

                is_payment_label = label.startswith("💳") or label.startswith("💵") or label.startswith("💸") or label.startswith("📲") or any(k in label for k in ["EFECTIVO", "TARJETA", "TRANSFERENCIA", "LUPAY"])
                is_total_label = ("TOTAL" in label and "SUBTOTAL" not in label) and not label.startswith("PAGADO") and not is_payment_label and not label.startswith("🪙")
                
                lbl_pt = pt * 1.20 if is_total_label else (pt * 1.25 if is_payment_label else pt)
                if is_total_label:
                    lbl_str = "TOTAL:"
                elif is_payment_label:
                    lbl_str = label.rstrip(":")
                else:
                    lbl_str = label
                fl = get_font(FONT_NAME, lbl_pt, is_total_label or is_bold or is_payment_label, use_emoji_font=has_emoji(lbl_str))
                hDC.SelectObject(fl)
                
                if is_payment_label and not val:
                    y += 4
                    y = wrap_and_draw_text(hDC, lbl_str, margin_left, margin_right, printable_width, y, align=1, line_spacing=6)
                    y += 4
                elif val:
                    lbl_w, lbl_h = hDC.GetTextExtent(lbl_str)
                    x_lbl = margin_left
                    hDC.TextOut(x_lbl, y, lbl_str)
                    
                    val_pt = pt * 1.25 if is_total_label else pt
                    fb = get_font(FONT_NAME, val_pt, True, use_emoji_font=has_emoji(val))
                    hDC.SelectObject(fb)
                    val_width, val_height = hDC.GetTextExtent(val)
                    x_val = max(margin_left + lbl_w + 10, width - margin_right - val_width)
                    hDC.TextOut(x_val, y, val)
                    y += max(lbl_h, val_height) + 6
                else:
                    y = wrap_and_draw_text(hDC, lbl_str, margin_left, margin_right, printable_width, y, align=1, line_spacing=4)
                
                if is_total_label:
                    monto_match = re.search(r'([0-9.,]+)', val) or re.search(r'([0-9.,]+)', text)
                    if monto_match:
                        try:
                            monto_clean = float(monto_match.group(1).replace(',', ''))
                            pending_total_amount = monto_clean
                        except Exception:
                            pass
                elif pending_total_amount is not None:
                    try:
                        letra_str = numero_a_letras(pending_total_amount)
                        if letra_str:
                            f_letra = get_font(FONT_NAME, base_pt * 0.85, True, is_italic=True, use_emoji_font=has_emoji(letra_str))
                            hDC.SelectObject(f_letra)
                            y = wrap_and_draw_text(hDC, letra_str, margin_left, margin_right, printable_width, y, align=1, line_spacing=3)
                            y = draw_solid_line(y + 4)
                    except Exception as ex_l:
                        notify_step("CONVERT_ERROR", f"Error convirtiendo total a letra: {ex_l}", status="WARNING")
                    pending_total_amount = None
                continue

            if pending_total_amount is not None:
                try:
                    letra_str = numero_a_letras(pending_total_amount)
                    if letra_str:
                        f_letra = get_font(FONT_NAME, base_pt * 0.85, True, is_italic=True, use_emoji_font=has_emoji(letra_str))
                        hDC.SelectObject(f_letra)
                        y = wrap_and_draw_text(hDC, letra_str, margin_left, margin_right, printable_width, y, align=1, line_spacing=3)
                        y = draw_solid_line(y + 4)
                except Exception:
                    pass
                pending_total_amount = None

            if text.startswith('*') or text.startswith('>'):
                f_italic = get_font(FONT_NAME, pt, False, is_italic=True, use_emoji_font=has_emoji(text))
                hDC.SelectObject(f_italic)
                y = wrap_and_draw_text(hDC, text, margin_left + 40, margin_right, printable_width - 40, y, align=0, line_spacing=3)
                continue
                
            if any(k in clean_upper for k in ["GRACIAS POR SU VISITA", "VUELVA PRONTO", "GRACIAS POR SU PREFERENCIA", "¡GRACIAS"]):
                clean_footer = re.sub(r'\s*\([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\)[a-zA-Z]*', '', text).strip()
                if clean_footer:
                    f_footer = get_font(FONT_NAME, base_pt * 1.05, True, is_italic=True, use_emoji_font=line_has_emoji)
                    hDC.SelectObject(f_footer)
                    y = wrap_and_draw_text(hDC, clean_footer, margin_left, margin_right, printable_width, y, align=1, line_spacing=4)
                    continue

            f_line = get_font(FONT_NAME, pt, bold_to_use, use_emoji_font=line_has_emoji)
            hDC.SelectObject(f_line)
            y = wrap_and_draw_text(hDC, text, margin_left, margin_right, printable_width, y, align=alignment, line_spacing=4)
            
        y += 90
        hDC.EndPage()
        hDC.EndDoc()
    finally:
        try:
            hDC.DeleteDC()
        except Exception:
            pass
            
        try:
            for f in font_cache.values():
                try:
                    f.DeleteObject()
                except:
                    pass
            font_cache.clear()
        except Exception:
            pass
            
        try:
            for p in pen_cache.values():
                try:
                    p.DeleteObject()
                except:
                    pass
            pen_cache.clear()
        except Exception:
            pass
            
        try:
            del hDC
        except Exception:
            pass

def print_data(printer_name: str, data_bytes: bytes, ticket_type: str = "comanda"):
    """
    Bypass unificado para impresión:
    - Modo 'hybrid' (predeterminado y óptimo para restaurantes):
        * Cuentas / Cobro / Cortes ('cuentas'): Renderizado GDI vectorial con logo y tipografía personalizada.
        * Comandas de Cocina y Barra ('cocina', 'barra'): ESC/POS directo a hardware (< 50ms) sin bloqueos ni contención de Windows.
    - Modo 'gdi': Todo en GDI vectorial.
    - Modo 'raw': Todo en ESC/POS directo.
    """
    global PRINT_MODE
    config_printers = load_printer_config()
    active_mode = config_printers.get("PRINT_MODE", PRINT_MODE).lower()

    use_gdi = False
    if active_mode == "gdi":
        use_gdi = True
    elif active_mode == "raw":
        use_gdi = False
    else:  # Modo 'hybrid'
        is_cuenta = str(ticket_type).lower() in ["cuentas", "cuenta", "corte", "cobro", "ticket", "caja"]
        use_gdi = is_cuenta

    if use_gdi:
        try:
            notify_step("2_PROCESS_EXEC", f"🎨 Renderizando ticket de cuenta en modo GDI ({ticket_type}) para [{printer_name}]", status="INFO")
            send_gdi_to_printer(printer_name, data_bytes, ticket_type)
        except Exception as e:
            notify_step("PRINT_FALLBACK", f"Fallo en GDI: {e}. Reintentando con bypass RAW directo...", status="WARNING")
            send_raw_to_printer(printer_name, data_bytes)
    else:
        notify_step("2_PROCESS_EXEC", f"⚡ Enviando comanda en modo ESC/POS directo ({ticket_type}) para [{printer_name}]", status="INFO")
        send_raw_to_printer(printer_name, data_bytes)

# ─── Endpoints de Flask ───────────────────────────────────────────
@app.route("/api/log-procesopico", methods=["POST", "OPTIONS"])
def receive_proceso_pico_log():
    if request.method == "OPTIONS":
        return jsonify({"ok": True}), 200
    try:
        data = request.get_json(silent=True) or {}
        logs = data.get("logs", [])
        if isinstance(logs, list):
            for item in logs:
                source = item.get("source", "FRONTEND_REACT")
                tipo = item.get("tipo", "PROCESO_PICO")
                operacion = item.get("operacion", "desconocida")
                duracion_ms = float(item.get("duracionMs", 0.0))
                status = item.get("status", "OK")
                detalles = item.get("detalles", None)
                log_proceso_pico(source, tipo, operacion, duracion_ms, status, detalles)
        elif isinstance(data, dict) and "operacion" in data:
            source = data.get("source", "FRONTEND_REACT")
            tipo = data.get("tipo", "PROCESO_PICO")
            operacion = data.get("operacion", "desconocida")
            duracion_ms = float(data.get("duracionMs", 0.0))
            status = data.get("status", "OK")
            detalles = data.get("detalles", None)
            log_proceso_pico(source, tipo, operacion, duracion_ms, status, detalles)
        return jsonify({"ok": True, "received": len(logs) if isinstance(logs, list) else 1}), 200
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 500

@app.route("/download/<filename>", methods=["GET"])
def download_sentinel_file(filename):
    safe_files = ["sentinel_printer.py", "instalador.bat", "instalador_sentinela.py", "printer_config.json"]
    if filename not in safe_files:
        return jsonify({"error": "File not allowed"}), 400
    file_path = os.path.join(BASE_DIR, filename)
    if not os.path.exists(file_path):
        return jsonify({"error": "File not found"}), 404
    from flask import send_file
    return send_file(file_path, as_attachment=True)

@app.route("/status", methods=["GET"])
def get_status():
    global PRINTER_MAP, PRINTER_PAPER_SIZES, LOGO_PATH, FONT_NAME, FONT_SIZE_PT
    config_printers = load_printer_config()
    PRINTER_MAP = config_printers.get("PRINTER_MAP", {})
    return jsonify({
        "status": "online",
        "service": "COCINET Print Sentinel",
        "version": VERSION,
        "port": PORT,
        "print_mode": PRINT_MODE,
        "ws_clients": len(ws_clients),
        "config": config_printers,
    })

@app.route("/printers", methods=["GET"])
def list_printers():
    global PRINTER_MAP
    config_printers = load_printer_config()
    PRINTER_MAP = config_printers["PRINTER_MAP"]

    installed = get_installed_printers()
    default = win32print.GetDefaultPrinter()
    return jsonify({"printers": installed, "default": default, "mapped": PRINTER_MAP})

@app.route("/config", methods=["GET", "POST"], endpoint="config_page")
@app.route("/api/config", methods=["GET", "POST"], endpoint="config_api")
def manage_config():
    if request.method == "POST":
        try:
            payload = {}
            if request.is_json:
                payload = request.get_json(silent=True) or {}
            else:
                form_data = request.form.to_dict()
                payload = form_data

            clean_cfg = {}
            if "FONT_NAME" in payload:
                clean_cfg["FONT_NAME"] = str(payload["FONT_NAME"]).strip()
            if "FONT_SIZE_PT" in payload:
                clean_cfg["FONT_SIZE_PT"] = float(payload["FONT_SIZE_PT"])
            if "HEADER_FONT_SIZE_PT" in payload:
                clean_cfg["HEADER_FONT_SIZE_PT"] = float(payload["HEADER_FONT_SIZE_PT"])
            if "ITEM_FONT_SIZE_PT" in payload:
                clean_cfg["ITEM_FONT_SIZE_PT"] = float(payload["ITEM_FONT_SIZE_PT"])
            if "TOTAL_FONT_SIZE_PT" in payload:
                clean_cfg["TOTAL_FONT_SIZE_PT"] = float(payload["TOTAL_FONT_SIZE_PT"])
            if "MARGIN_LEFT_PX" in payload:
                clean_cfg["MARGIN_LEFT_PX"] = int(payload["MARGIN_LEFT_PX"])
            if "MARGIN_RIGHT_PX" in payload:
                clean_cfg["MARGIN_RIGHT_PX"] = int(payload["MARGIN_RIGHT_PX"])
            if "LINE_SPACING" in payload:
                clean_cfg["LINE_SPACING"] = int(payload["LINE_SPACING"])
            if "SHOW_DIVIDER" in payload:
                val = payload["SHOW_DIVIDER"]
                clean_cfg["SHOW_DIVIDER"] = val in [True, "true", "True", "1", 1, "on"]
            if "LOGO_PATH" in payload:
                clean_cfg["LOGO_PATH"] = str(payload["LOGO_PATH"]).strip()
            if "BACKUP_FOLDER" in payload:
                clean_cfg["BACKUP_FOLDER"] = str(payload["BACKUP_FOLDER"]).strip()

            if "PRINTER_MAP" in payload and isinstance(payload["PRINTER_MAP"], dict):
                clean_cfg["PRINTER_MAP"] = payload["PRINTER_MAP"]
            if "PRINTER_PAPER_SIZES" in payload and isinstance(payload["PRINTER_PAPER_SIZES"], dict):
                clean_cfg["PRINTER_PAPER_SIZES"] = payload["PRINTER_PAPER_SIZES"]

            updated = save_printer_config(clean_cfg)
            return jsonify({"success": True, "config": updated})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    cfg = load_printer_config()
    return jsonify({"success": True, "config": cfg})

print_lock = threading.Lock()
internal_print_queue = queue.Queue()

def purge_stuck_windows_jobs(printer_name: str):
    """Cancela trabajos atascados o con error en el Spooler de Windows."""
    try:
        hPrinter = win32print.OpenPrinter(printer_name)
        try:
            jobs = win32print.EnumJobs(hPrinter, 0, -1, 1)
            for job in jobs:
                job_id = job['JobId']
                status = job['Status']
                # Si el trabajo tiene error, o se quedó atascado por falta de papel o offline
                if status & (win32print.JOB_STATUS_ERROR | win32print.JOB_STATUS_OFFLINE | win32print.JOB_STATUS_PAPEROUT):
                    win32print.SetJob(hPrinter, job_id, 0, None, win32print.JOB_CONTROL_CANCEL)
                    notify_step("SPOOLER_CLEANUP", f"Trabajo atascado/error (ID {job_id}) eliminado del Spooler en {printer_name}.", status="WARNING")
        finally:
            win32print.ClosePrinter(hPrinter)
    except Exception as e:
        notify_step("SPOOLER_CLEANUP_ERR", f"No se pudo limpiar el spooler de {printer_name}: {e}", status="WARNING")

def internal_print_worker():
    notify_step("WORKER_START", "Hilo de cola de impresión interna iniciado.", status="INFO")
    while True:
        try:
            job = internal_print_queue.get()
            if job is None:
                break
                
            printer_key = job.get("printer_key")
            raw_bytes = job.get("raw_bytes")
            
            notify_step("WORKER_PROCESS", f"Procesando ticket para '{printer_key}' desde la cola interna.")
            
            try:
                printer_name = resolve_printer_name(printer_key)
                
                # Vaciar bufer de trabajos atascados inmediatamente antes de imprimir
                purge_stuck_windows_jobs(printer_name)
                
                # Bloqueo para que solo 1 ticket a la vez vaya al spooler y no lo sature
                with print_lock:
                    print_data(printer_name, raw_bytes, ticket_type=printer_key)
                    time.sleep(0.35)  # Pausa de seguridad para que el puerto e impresora de red liberen el socket
                    
                notify_step("WORKER_COMPLETE", f"🎉 Ticket impreso exitosamente en [{printer_name}]", status="SUCCESS")
            except Exception as print_ex:
                notify_step("WORKER_ERROR", f"❌ El trabajo para '{printer_key}' NO se imprimió. Razón: {print_ex}", status="ERROR")
            finally:
                internal_print_queue.task_done()
        except Exception as e:
            notify_step("WORKER_CRITICAL", f"Error crítico en el hilo de impresión: {e}", status="ERROR")
            time.sleep(2)

@app.route("/print", methods=["POST"])
def print_ticket():
    try:
        raw_payload = request.get_data(as_text=True)
        notify_step("0_INCOMING", f"POST /print recibido. Tamaño payload: {len(raw_payload)}")
    except Exception:
        pass

    data = request.get_json(silent=True)
    if not data:
        notify_step("0_ERROR", "POST /print recibido pero no tiene JSON valido", status="ERROR")
        return jsonify({"success": False, "error": "No data received"}), 400
        
    printer_key  = data.get("printer", "cuentas")
    raw_data_url = data.get("raw_data", "")
    raw_bytes    = urllib.parse.unquote_to_bytes(raw_data_url)
    
    notify_step("1_RECEIVE", f"Solicitud de impresión recibida vía POST /print para clave '{printer_key}'", extra_data={"bytes_len": len(raw_bytes)})

    try:
        text_repr = raw_bytes.decode("utf-8", errors="ignore")
        if "*** COCINA" in text_repr or "*** BARRA" in text_repr or "*** GENERAL" in text_repr:
            notify_step("DROP_SMALL_TICKET", f"🚫 Parche de supresión: Comanda pequeña duplicada para '{printer_key}' descartada en el servidor.", status="WARNING")
            return jsonify({"success": True, "ignored": True, "reason": "suppressed_small_ticket", "bytes_sent": 0})
    except Exception:
        pass

    if check_duplicate_and_register(raw_bytes):
        notify_step("2_PROCESS_DUP", "Ticket duplicado detectado por Hash, omitiendo impresión", status="WARNING")
        return jsonify({"success": True, "ignored": True, "reason": "duplicate", "bytes_sent": 0})
        
    # Encolar para impresión asíncrona
    internal_print_queue.put({
        "printer_key": printer_key,
        "raw_bytes": raw_bytes
    })
    notify_step("2_ENQUEUED", f"Ticket para '{printer_key}' añadido a la cola de impresión interna.")
    
    # Resolver nombre de impresora sincrónicamente solo para retrocompatibilidad de API
    printer_name = resolve_printer_name(printer_key)
    
    # Responder inmediatamente para evitar bloqueos
    return jsonify({"success": True, "queued": True, "printer_key": printer_key, "printer_used": printer_name, "bytes_sent": len(raw_bytes)})
@app.route("/backup-sale", methods=["POST"])
def backup_sale():
    try:
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"success": False, "error": "No data received"}), 400
            
        tenant_id = data.get("tenantId", "unknown")
        
        # Lógica de Turno / Día de Operación (6:00 AM corte)
        now = datetime.now()
        if now.hour < 6:
            op_date = now - timedelta(days=1)
        else:
            op_date = now
            
        op_day_str = op_date.strftime("%Y-%m-%d")
        
        # Guardar en BACKUP_FOLDER desde configuración
        backup_dir = BACKUP_FOLDER
        os.makedirs(backup_dir, exist_ok=True)
        
        filename = f"respaldo_tikets_{tenant_id}_{op_day_str}.log"
        filepath = os.path.join(backup_dir, filename)
        
        # Añadir timestamp de recepción local al registro
        data["_localReceivedAt"] = now.isoformat()
        
        with open(filepath, "a", encoding="utf-8") as f:
            f.write(json.dumps(data, ensure_ascii=False) + "\n")
            
        notify_step("BACKUP_SALE", f"Venta respaldada localmente para tenant {tenant_id} en {filename}", status="SUCCESS")
        return jsonify({"success": True, "file": filename})
    except Exception as e:
        notify_step("BACKUP_ERROR", f"Error guardando respaldo de venta: {e}", status="ERROR")
        return jsonify({"success": False, "error": str(e)}), 500

# ─── Respaldo de Movimientos del Turno (C:\buzon\respaldos\turnos) ─────────────
@app.route("/backup-turno", methods=["POST"], endpoint="backup_turno_root")
@app.route("/api/backup-turno", methods=["POST"], endpoint="backup_turno_api")
def backup_turno():
    r"""
    Guarda el respaldo completo del turno (sesión, corte, cuentas, gastos y movimientos)
    en formato JSON legible en la subcarpeta C:\buzon\respaldos\turnos\.
    """
    try:
        data = request.get_json(silent=True)
        if not data:
            return jsonify({"success": False, "error": "No data received"}), 400
            
        tenant_id = data.get("tenantId", "general")
        session_id = str(data.get("sessionId", "turno_sin_id")).replace(":", "-").replace("/", "-")
        op_date = data.get("opDate") or datetime.now().strftime("%Y-%m-%d")
        
        # Carpeta C:\buzon\respaldos\turnos
        turnos_dir = os.path.join(BACKUP_FOLDER, "turnos")
        os.makedirs(turnos_dir, exist_ok=True)
        
        now = datetime.now()
        
        # Limpieza de nombre de archivo
        clean_tenant = re.sub(r'[^a-zA-Z0-9_-]', '_', str(tenant_id))
        clean_session = re.sub(r'[^a-zA-Z0-9_-]', '_', str(session_id))
        clean_date = re.sub(r'[^a-zA-Z0-9_-]', '_', str(op_date))
        
        filename = f"turno_{clean_tenant}_{clean_date}_{clean_session}.json"
        filepath = os.path.join(turnos_dir, filename)
        
        # Metadata de auditoría
        data["_savedLocallyAt"] = now.isoformat()
        data["_savedFilename"] = filename
        data["_localPath"] = filepath
        
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            
        file_size = os.path.getsize(filepath)
        
        notify_step("BACKUP_TURNO", f"📦 Turno [{clean_session}] respaldado exitosamente en C:\\buzon\\respaldos\\turnos\\{filename} ({file_size} bytes)", status="SUCCESS")
        return jsonify({
            "success": True,
            "filename": filename,
            "filepath": filepath,
            "size": file_size,
            "turnos_dir": turnos_dir,
            "savedAt": now.isoformat()
        })
    except Exception as e:
        notify_step("BACKUP_TURNO_ERR", f"Error guardando respaldo de turno: {e}", status="ERROR")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/backup-turnos", methods=["GET"])
@app.route("/api/backup-turnos", methods=["GET"])
def list_backup_turnos():
    """
    Lista todos los respaldos de turnos existentes en C:\buzon\respaldos\turnos\
    con sus metadatos para visualizarlos en la línea del tiempo.
    """
    try:
        turnos_dir = os.path.join(BACKUP_FOLDER, "turnos")
        os.makedirs(turnos_dir, exist_ok=True)
        
        backups = []
        for fname in os.listdir(turnos_dir):
            if fname.endswith(".json"):
                fpath = os.path.join(turnos_dir, fname)
                try:
                    stat = os.stat(fpath)
                    summary = {
                        "filename": fname,
                        "filepath": fpath,
                        "size": stat.st_size,
                        "modifiedAt": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                        "tenantId": "",
                        "tenantName": "",
                        "sessionId": "",
                        "openedAt": "",
                        "closedAt": "",
                        "userName": "",
                        "totalVentas": 0,
                        "ticketsCount": 0,
                        "note": "",
                        "status": "closed",
                    }
                    with open(fpath, "r", encoding="utf-8") as f:
                        content = json.load(f)
                        summary["tenantId"] = content.get("tenantId", "")
                        summary["tenantName"] = content.get("tenantName", "")
                        summary["sessionId"] = content.get("sessionId", "")
                        summary["openedAt"] = content.get("openedAt", "")
                        summary["closedAt"] = content.get("closedAt", "")
                        summary["userName"] = content.get("userName") or content.get("cajero", "")
                        summary["totalVentas"] = content.get("totalVentas", 0)
                        summary["ticketsCount"] = len(content.get("sales", [])) if "sales" in content else content.get("ticketsCount", 0)
                        summary["note"] = content.get("note", "")
                        summary["status"] = content.get("status", "closed")
                    backups.append(summary)
                except Exception as ex:
                    backups.append({
                        "filename": fname,
                        "filepath": fpath,
                        "size": os.path.getsize(fpath) if os.path.exists(fpath) else 0,
                        "error": str(ex)
                    })
                    
        # Ordenar por fecha de modificación más reciente primero
        backups.sort(key=lambda x: x.get("modifiedAt", ""), reverse=True)
        
        return jsonify({
            "success": True,
            "turnos_dir": turnos_dir,
            "count": len(backups),
            "backups": backups
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/backup-turno/<filename>", methods=["GET", "DELETE"])
@app.route("/api/backup-turno/<filename>", methods=["GET", "DELETE"])
def manage_single_backup_turno(filename):
    try:
        clean_filename = os.path.basename(filename)
        turnos_dir = os.path.join(BACKUP_FOLDER, "turnos")
        filepath = os.path.join(turnos_dir, clean_filename)
        
        if not os.path.exists(filepath):
            return jsonify({"success": False, "error": "Archivo no encontrado"}), 404
            
        if request.method == "DELETE":
            os.remove(filepath)
            notify_step("BACKUP_TURNO_DEL", f"Respaldo eliminado: {clean_filename}", status="WARNING")
            return jsonify({"success": True, "deleted": clean_filename})
            
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
        return jsonify({"success": True, "data": data, "filename": clean_filename})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route("/test-print", methods=["GET", "POST"])
def test_print():
    try:
        data         = request.get_json(silent=True) or {}
        printer_key  = data.get("printer", "cuentas")
        notify_step("1_RECEIVE_TEST", f"Iniciando impresión de prueba para clave '{printer_key}'")

        printer_name = resolve_printer_name(printer_key)

        ESC = b"\x1b"
        GS  = b"\x1d"
        now = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        parts = [
            ESC + b"@",
            ESC + b"a\x01",
            ESC + b"!\x18",
            "🌮 TACOS ROY AZUCENAS 🌮\n".encode("utf-8"),
            ESC + b"!\x00",
            "=== TICKET PRO GDI VECTORIAL ===\n\n".encode("utf-8"),
            ESC + b"a\x00",
            f"Impresora : {printer_name}\n".encode("utf-8"),
            f"Sentinel  : v{VERSION} (Puerto {PORT})\n".encode("utf-8"),
            f"Fecha     : {now}\n".encode("utf-8"),
            "Atendio   : BLADIMIR (ADMIN) 👤\n".encode("utf-8"),
            "----------------------------------------\n".encode("utf-8"),
            "2 x 🌮 TACOS AL PASTOR      $100.00\n".encode("utf-8"),
            "  * Con todo y salsa verde\n".encode("utf-8"),
            "1 x 🍺 CERVEZA ARTESANAL    $80.00\n".encode("utf-8"),
            "1 x 🍹 MARGARITA AZUL       $95.50\n".encode("utf-8"),
            "----------------------------------------\n".encode("utf-8"),
            "SUBTOTAL: $275.50\n".encode("utf-8"),
            "PROPINA (10%): $27.55\n".encode("utf-8"),
            "TOTAL: $303.05\n".encode("utf-8"),
            "----------------------------------------\n".encode("utf-8"),
            ESC + b"a\x01",
            "¡Gracias por su preferencia! ⭐\n".encode("utf-8"),
            "Facturacion: www.cocinet.app 🌐\n".encode("utf-8"),
            b"\n\n\n",
            GS + b"V\x41\x03"
        ]
        test_bytes = b"".join(parts)

        with print_lock:
            print_data(printer_name, test_bytes, ticket_type=printer_key)
        notify_step("4_COMPLETE_TEST", f"🎉 Página de prueba emitida correctamente en [{printer_name}]", status="SUCCESS")
        return jsonify({"success": True, "printer_used": printer_name})
    except Exception as e:
        notify_step("4_ERROR_TEST", f"❌ Error en test-print: {e}", status="ERROR")
        return jsonify({"error": str(e)}), 500

@app.route("/diag-print", methods=["POST"])
def diag_print():
    logs = []
    def add_log(msg):
        timestamp = datetime.now().strftime('%H:%M:%S')
        full_msg = f"{timestamp} - {msg}"
        logs.append(full_msg)
        notify_step("DIAG_STEP", msg)

    try:
        data = request.get_json(silent=True) or {}
        printer_key = data.get("printer", "cuentas")
        add_log(f"Iniciando diagnóstico para impresora clave: {printer_key}")

        printer_name = resolve_printer_name(printer_key)
        add_log(f"Impresora resuelta: {printer_name}")

        ESC = b"\x1b"
        GS  = b"\x1d"
        test_bytes = ESC + b"@" + b"Diagnostico OK\n" + GS + b"V\x41\x03"

        add_log("Intentando imprimir página de prueba de diagnóstico...")
        with print_lock:
            print_data(printer_name, test_bytes, ticket_type=printer_key)
        add_log("Impresión de diagnóstico completada.")

        return jsonify({"success": True, "logs": logs})
    except Exception as e:
        err_msg = f"Error durante diagnóstico: {str(e)}"
        add_log(err_msg)
        return jsonify({"success": False, "logs": logs, "error": str(e)}), 500

# ─── Servir Aplicación Web SPA (React dist) en Puerto 3010 ─────────
def get_dist_dir():
    candidates = [
        os.path.join(BASE_DIR, "dist"),
        os.path.join(os.path.dirname(BASE_DIR), "dist"),
        os.path.join(os.path.dirname(os.path.dirname(BASE_DIR)), "dist"),
        r"C:\buzon\TAREAS\cocinet-app2\cocinet-app-main antes del exe\dist",
        r"C:\buzon\TAREAS\cocinet-app2\cocinet-app-main antes del exe\public\Cocinet_Windows_App\dist",
    ]
    for c in candidates:
        if os.path.exists(c) and os.path.isdir(c):
            return c
    return None

@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_spa(path):
    if path.startswith("api/"):
        return jsonify({"error": "Endpoint not found"}), 404

    dist_dir = get_dist_dir()
    if dist_dir and os.path.exists(dist_dir):
        target_path = os.path.join(dist_dir, path)
        if path and os.path.exists(target_path) and not os.path.isdir(target_path):
            return send_from_directory(dist_dir, path)
        index_file = os.path.join(dist_dir, "index.html")
        if os.path.exists(index_file):
            return send_from_directory(dist_dir, "index.html")

    return f"""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>COCINET PRO - Sentinel</title>
        <style>
            body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; }}
            .card {{ background: #1e293b; padding: 40px; border-radius: 16px; border: 1px solid #334155; text-align: center; max-width: 480px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }}
            h1 {{ color: #10b981; font-size: 24px; margin-bottom: 12px; }}
            p {{ color: #94a3b8; line-height: 1.6; font-size: 14px; }}
            .badge {{ display: inline-block; background: #064e3b; color: #34d399; padding: 6px 14px; border-radius: 20px; font-weight: bold; font-size: 13px; margin-bottom: 15px; }}
            code {{ background: #334155; color: #f1f5f9; padding: 3px 8px; border-radius: 4px; font-family: monospace; font-size: 13px; }}
        </style>
    </head>
    <body>
        <div class="card">
            <span class="badge">● SERVICIO ACTIVO (Puerto {PORT})</span>
            <h1>COCINET Print Sentinel v{VERSION}</h1>
            <p>El servicio de impresión en segundo plano está operando correctamente.</p>
            <p style="color: #f59e0b; margin-top: 15px;">⚠️ Para visualizar la interfaz de Cocinet en este puerto, ejecute <code>python empaquetar_windows.py</code> para compilar la carpeta <code>dist</code>.</p>
        </div>
    </body>
    </html>
    """, 200

# ─── Deduplicación por Hash en Memoria RAM ─────────────────────────
_recent_ticket_hashes = {}

def generar_hash(raw_bytes: bytes) -> str:
    return hashlib.md5(raw_bytes).hexdigest()

def check_duplicate_and_register(raw_bytes: bytes, job_id: str = None) -> bool:
    ticket_hash = generar_hash(raw_bytes)
    now = time.time()
    
    # Limpiar hashes de más de 2.5 segundos (evita dobles clics pero permite reimpresiones rápidas)
    expired = [h for h, t in list(_recent_ticket_hashes.items()) if now - t > 2.5]
    for h in expired:
        _recent_ticket_hashes.pop(h, None)
        
    if ticket_hash in _recent_ticket_hashes:
        return True
        
    _recent_ticket_hashes[ticket_hash] = now
    return False

# ─── Polling DB ───────────────────────────────────────────────────
def db_polling_loop():
    db_path = os.path.join(BASE_DIR, "restaurant.db")
    notify_step("DB_POLL_START", f"Iniciando polling de base de datos SQLite en: {db_path}")
    while True:
        try:
            conn = sqlite3.connect(db_path, timeout=30)
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS print_queue (
                    id TEXT PRIMARY KEY,
                    printer_key TEXT NOT NULL,
                    raw_data TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    hash TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    printed_at TIMESTAMP
                )
            """)
            conn.commit()
            conn.close()
            
            conn = sqlite3.connect(db_path, timeout=30)
            conn.execute("BEGIN IMMEDIATE")
            cursor = conn.cursor()
            cursor.execute("SELECT id, printer_key, raw_data FROM print_queue WHERE status='pending'")
            jobs = cursor.fetchall()
            
            if jobs:
                for job_id, _, _ in jobs:
                    cursor.execute("UPDATE print_queue SET status='processing', updated_at=CURRENT_TIMESTAMP WHERE id=?", (job_id,))
                conn.commit()
            else:
                conn.commit()
            conn.close()
            
            for job_id, printer_key, raw_data in jobs:
                try:
                    notify_step("1_RECEIVE_DB", f"Trabajo recuperado de cola DB (ID: {job_id}) para '{printer_key}'")
                    raw_bytes = urllib.parse.unquote_to_bytes(raw_data)
                    ticket_hash = generar_hash(raw_bytes)
                    
                    if check_duplicate_and_register(raw_bytes, job_id):
                        notify_step("2_PROCESS_DB_DUP", f"Ticket duplicado omitido en DB cola (ID: {job_id})", status="WARNING")
                        continue
                    
                    printer_name = resolve_printer_name(printer_key)
                    purge_stuck_windows_jobs(printer_name)
                    with print_lock:
                        print_data(printer_name, raw_bytes, ticket_type=printer_key)
                    
                    conn2 = sqlite3.connect(db_path, timeout=30)
                    cursor2 = conn2.cursor()
                    cursor2.execute("""
                        UPDATE print_queue
                        SET status='printed', updated_at=CURRENT_TIMESTAMP, printed_at=CURRENT_TIMESTAMP, hash=?
                        WHERE id=?
                    """, (ticket_hash, job_id))
                    conn2.commit()
                    conn2.close()
                    notify_step("4_COMPLETE_DB", f"🎉 Ticket DB impreso con éxito (ID: {job_id}, Impresora: {printer_name})", status="SUCCESS")
                    
                except Exception as ex:
                    notify_step("4_ERROR_DB", f"❌ Error procesando trabajo DB {job_id}: {ex}", status="ERROR")
                    conn2 = sqlite3.connect(db_path, timeout=30)
                    cursor2 = conn2.cursor()
                    cursor2.execute("UPDATE print_queue SET status='failed', updated_at=CURRENT_TIMESTAMP WHERE id=?", (job_id,))
                    conn2.commit()
                    conn2.close()
            
            time.sleep(2)
        except Exception as e:
            notify_step("DB_POLL_ERROR", f"Error en bucle de polling: {e}", status="WARNING")
            time.sleep(5)

# ─── Servicio Windows ─────────────────────────────────────────────
class CocinetPrinterService(win32serviceutil.ServiceFramework):
    _svc_name_ = "CocinetPrinterSentinel"
    _svc_display_name_ = "COCINET PRO - Print Sentinel"
    _svc_description_ = "Servidor local HTTP & WebSockets de impresión ESC/POS para COCINET PRO."

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)

    def SvcStop(self):
        notify_step("SERVICE_STOP", "Servicio detenido por el Administrador de Servicios de Windows (SCM).")
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        stop_flask()
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ""),
        )
        notify_step("SERVICE_START", "Servicio iniciado en segundo plano por Windows SCM.")
        flask_thread = threading.Thread(target=run_flask, daemon=True)
        flask_thread.start()
        win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)

def run_flask():
    try:
        db_thread = threading.Thread(target=db_polling_loop, daemon=True)
        db_thread.start()
        
        worker_thread = threading.Thread(target=internal_print_worker, daemon=True)
        worker_thread.start()
        
        from werkzeug.serving import make_server
        global _flask_server
        _flask_server = make_server("0.0.0.0", PORT, app)
        notify_step("SERVICE_ONLINE", f"COCINET Print Sentinel v{VERSION} escuchando en puerto {PORT} (HTTP/WS)")
        _flask_server.serve_forever()
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        write_crash_log("FLASK_CRASH", str(e), error_details)
        notify_step("SERVICE_CRASH", f"Servicio HTTP interrumpido: {e}", status="ERROR")
        import os
        os._exit(1) # Forza el cierre del proceso para que Windows active la Recuperación Automática

def stop_flask():
    global _flask_server
    try:
        _flask_server.shutdown()
    except Exception:
        pass

def run_console():
    print()
    print("============================================================")
    print(f"   COCINET PRO - Windows Print Sentinel  v{VERSION}")
    print("============================================================")
    print(f"   HTTP API:  http://localhost:{PORT}")
    print(f"   WebSocket: ws://localhost:{PORT}/ws")
    print(f"   Modo:      GDI Vectorial & Traza Paso a Paso")
    print("------------------------------------------------------------")
    try:
        installed = get_installed_printers()
        print(f"  Impresoras detectadas ({len(installed)}):")
        for p in installed:
            found = any(v.upper() == p.upper() for v in PRINTER_MAP.values())
            tag   = "[MAPEADA]   " if found else "[disponible]"
            print(f"    {tag}  {p}")
    except Exception as e:
        print(f"  [WARN] No se pudo listar impresoras: {e}")
    print()
    print("  Presiona Ctrl+C para detener.\n")
    try:
        run_flask()
    except KeyboardInterrupt:
        print("\n  Servidor detenido por consola.")

def purge_legacy_cocinet_services():
    """Purga cualquier servicio legacy de Cocinet que no sea el oficial CocinetPrinterSentinel."""
    try:
        ps_cmd = 'powershell -Command "Get-Service *Cocinet* | Select-Object -ExpandProperty Name"'
        res = subprocess.run(ps_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True, timeout=10)
        found = [line.strip() for line in res.stdout.splitlines() if line.strip()]
        for s in found:
            if s and s != "CocinetPrinterSentinel":
                subprocess.run(f'sc stop "{s}"', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                subprocess.run(f'sc delete "{s}"', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                subprocess.run(f'reg delete "HKLM\\SYSTEM\\CurrentControlSet\\Services\\{s}" /f', shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    except Exception:
        pass

if __name__ == "__main__":
    if len(sys.argv) == 1:
        run_console()
    else:
        if any(arg.lower() in ["install", "--install"] for arg in sys.argv):
            purge_legacy_cocinet_services()
        win32serviceutil.HandleCommandLine(CocinetPrinterService)