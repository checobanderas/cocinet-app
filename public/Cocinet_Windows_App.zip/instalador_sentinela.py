# -*- coding: utf-8 -*-
"""
================================================================================
   🚀 COCINET PRO - Instalador y Actualizador del Sentinela de Windows v3.1 🚀
================================================================================
Este script detiene, desinstala, actualiza dependencias y reinstala de forma
limpia el servicio de Windows del Sentinela de Impresión COCINET PRO.

Requisitos:
  - Ejecutar en Windows con Python 3 instalado.
  - Se auto-elevará a permisos de Administrador automáticamente si es necesario.
================================================================================
"""

import os
import sys
import time
import subprocess
import urllib.request
import json
import argparse

# Asegurar codificación UTF-8 en consola de Windows para evitar errores con Emojis
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

# Nombre exacto del servicio de Windows
SERVICE_NAME = "CocinetPrinterSentinel"
SENTINEL_SCRIPT = "sentinel_printer.py"
PORT = 3010

def is_admin():
    """Verifica si el script tiene privilegios de Administrador."""
    try:
        import ctypes
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False

def elevate_privileges():
    """Intenta re-ejecutar el script actual con permisos de Administrador manteniendo la consola visible."""
    import ctypes
    # Si ya es admin, no hacemos nada
    if is_admin():
        return True
    
    print("🔑 [INFO] Solicitando elevación de privilegios de Administrador... Por favor acepta el diálogo de Windows.")
    try:
        script = os.path.abspath(sys.argv[0])
        script_dir = os.path.dirname(script)
        params = " ".join(sys.argv[1:])
        cmd_args = f'/k cd /d "{script_dir}" && "{sys.executable}" "{script}" {params}'
        result = ctypes.windll.shell32.ShellExecuteW(None, "runas", "cmd.exe", cmd_args, script_dir, 1)
        if int(result) > 32:
            print("🚀 [OK] Re-lanzando proceso con permisos de administrador en nueva consola...")
            sys.exit(0)
        else:
            print("❌ [ERROR] No se concedieron los permisos de Administrador necesarios.")
            return False
    except Exception as e:
        print(f"❌ [ERROR] Error al intentar elevar privilegios: {e}")
        return False

def print_banner():
    print("\n" + "="*80)
    print("   🌟 COCINET PRO - ACTUALIZADOR DE SERVICIO DE WINDOWS PARA EL SENTINELA 🌟")
    print("="*80 + "\n")

def run_command(args, step_name, ignore_error=False):
    """Ejecuta un comando del sistema informando detalladamente con emojis."""
    print(f"⏳ [PROCESANDO] Paso: {step_name}...")
    try:
        # Usamos shell=True para comandos internos o scripts
        result = subprocess.run(
            args, 
            stdout=subprocess.PIPE, 
            stderr=subprocess.PIPE, 
            text=True, 
            timeout=30,
            shell=True
        )
        if result.returncode == 0:
            print(f"✅ [ÉXITO] Paso '{step_name}' completado correctamente.")
            return True
        else:
            if ignore_error:
                print(f"⚠️ [AVISO] Paso '{step_name}' finalizó con código {result.returncode} (Ignorado).")
                return True
            print(f"❌ [ERROR] Falló el paso: {step_name}")
            print(f"   Detalles del sistema: {result.stderr.strip() or result.stdout.strip()}")
            return False
    except subprocess.TimeoutExpired:
        print(f"⏰ [TIMEOUT] Se agotó el tiempo de espera (30s) para: {step_name}")
        return False
    except Exception as e:
        print(f"💥 [CRÍTICO] Excepción en '{step_name}': {e}")
        return False

def check_sentinel_file():
    """Verifica que el archivo del sentinela exista en la misma carpeta."""
    current_dir = os.path.dirname(os.path.abspath(__file__))
    target_path = os.path.join(current_dir, SENTINEL_SCRIPT)
    if os.path.exists(target_path):
        return target_path
    
    # Buscar en el directorio actual de ejecución
    if os.path.exists(SENTINEL_SCRIPT):
        return os.path.abspath(SENTINEL_SCRIPT)
        
    return None

def verify_service_status():
    """Realiza una petición HTTP al puerto del Sentinela para verificar que esté activo."""
    print(f"🔍 [VERIFICACIÓN] Conectando con el Sentinela en http://localhost:{PORT}/status ...")
    time.sleep(2) # Esperar a que el servicio se asiente
    try:
        url = f"http://localhost:{PORT}/status"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=3) as response:
            if response.status == 200:
                data = json.loads(response.read().decode('utf-8'))
                print("\n🎉 ¡EL SENTINELA SE ENCUENTRA EN LÍNEA Y OPERANDO CON ÉXITO! 🎉")
                print(f"   📡 Estado: {data.get('status', 'desconocido').upper()}")
                print(f"   🛠️  Servicio: {data.get('service', 'N/A')}")
                print(f"   🏷️  Versión Instalada: v{data.get('version', '7.0.0-PRO')}")
                print(f"   🔌 Puerto: {data.get('port', PORT)}")
                print(f"   📋 Impresoras Mapeadas: {list(data.get('mapped_printers', {}).keys())}")
                print("   ✨ Novedades v7.0.0-PRO:")
                print("      • 🛡️ Diagnóstico de caídas automático registrado en 'sentinel_crash.log'.")
                print("      • 🔄 Reconexión automática transparente en puerto 3010 con auto-reintentos.")
                print("      • ⚡ Encolado de contingencia en base de datos SQLite.")
                print("      • 🖨️ Despliegue estricto de 1 línea por producto con montos exactos.")
                print("================================================================================")
                print("💡 ¡Listo! El Sentinela de Windows ya está actualizado e impresoras listas.")
                print("================================================================================\n")
                return True
    except Exception as e:
        print(f"⚠️ [AVISO] No se pudo obtener respuesta HTTP directa del Sentinela ({e}).")
        print("   Sin embargo, el servicio de Windows se ha configurado e iniciado en segundo plano.")
        print("   Puedes revisar los logs detallados en 'sentinel.log' para confirmar su operación.")
        return False

def configure_printer_sizes(target_dir, env_mode="production"):
    """Pregunta al usuario por consola interactiva los nombres, anchos de papel, logotipo, respaldos y tamaños de tipografía GDI."""
    config_file = os.path.join(target_dir, "printer_config.json")
    
    # Valores base por defecto optimizados con letra grande y legible
    current_config = {
        "PRINTER_MAP": {
            "cuentas": "CUENTAS",
            "cocina":  "COCINA",
            "barra":   "BARRA",
        },
        "PRINTER_PAPER_SIZES": {
            "cuentas": "80mm",
            "cocina":  "80mm",
            "barra":   "80mm",
        },
        "LOGO_PATH": "C:\\buzon\\logo.jpg",
        "FONT_NAME": "Arial",
        "FONT_SIZE_PT": 12.0,
        "HEADER_FONT_SIZE_PT": 18.0,
        "ITEM_FONT_SIZE_PT": 14.0,
        "TOTAL_FONT_SIZE_PT": 16.0,
        "MARGIN_LEFT_PX": 10,
        "MARGIN_RIGHT_PX": 25,
        "LINE_SPACING": 4,
        "SHOW_DIVIDER": True,
        "BACKUP_FOLDER": "C:\\buzon\\respaldos",
        "ENVIRONMENT": env_mode,
        "DEBUG_VERBOSE": (env_mode == "testing"),
        "DB_PATH": "restaurant.db",
        "LOG_FILE": "sentinel_printer.log",
        "POLL_INTERVAL_SECONDS": 2,
        "DEDUP_TTL_SECONDS": 10
    }
    
    # Leer el existente si existe para conservar la config anterior del usuario
    if os.path.exists(config_file):
        try:
            with open(config_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                if "PRINTER_MAP" in data and isinstance(data["PRINTER_MAP"], dict):
                    current_config["PRINTER_MAP"].update(data["PRINTER_MAP"])
                if "PRINTER_PAPER_SIZES" in data and isinstance(data["PRINTER_PAPER_SIZES"], dict):
                    current_config["PRINTER_PAPER_SIZES"].update(data["PRINTER_PAPER_SIZES"])
                if "LOGO_PATH" in data:
                    current_config["LOGO_PATH"] = data["LOGO_PATH"]
                if "FONT_NAME" in data:
                    current_config["FONT_NAME"] = data["FONT_NAME"]
                if "FONT_SIZE_PT" in data:
                    current_config["FONT_SIZE_PT"] = float(data["FONT_SIZE_PT"])
                if "HEADER_FONT_SIZE_PT" in data:
                    current_config["HEADER_FONT_SIZE_PT"] = float(data["HEADER_FONT_SIZE_PT"])
                if "ITEM_FONT_SIZE_PT" in data:
                    current_config["ITEM_FONT_SIZE_PT"] = float(data["ITEM_FONT_SIZE_PT"])
                if "TOTAL_FONT_SIZE_PT" in data:
                    current_config["TOTAL_FONT_SIZE_PT"] = float(data["TOTAL_FONT_SIZE_PT"])
                if "MARGIN_LEFT_PX" in data:
                    current_config["MARGIN_LEFT_PX"] = int(data["MARGIN_LEFT_PX"])
                if "MARGIN_RIGHT_PX" in data:
                    current_config["MARGIN_RIGHT_PX"] = int(data["MARGIN_RIGHT_PX"])
                if "LINE_SPACING" in data:
                    current_config["LINE_SPACING"] = int(data["LINE_SPACING"])
                if "SHOW_DIVIDER" in data:
                    current_config["SHOW_DIVIDER"] = bool(data["SHOW_DIVIDER"])
                if "BACKUP_FOLDER" in data:
                    current_config["BACKUP_FOLDER"] = data["BACKUP_FOLDER"]
                if "DB_PATH" in data:
                    current_config["DB_PATH"] = data["DB_PATH"]
                if "LOG_FILE" in data:
                    current_config["LOG_FILE"] = data["LOG_FILE"]
                if "POLL_INTERVAL_SECONDS" in data:
                    current_config["POLL_INTERVAL_SECONDS"] = data["POLL_INTERVAL_SECONDS"]
                if "DEDUP_TTL_SECONDS" in data:
                    current_config["DEDUP_TTL_SECONDS"] = data["DEDUP_TTL_SECONDS"]
        except Exception:
            pass
            
    print("\n" + "="*80)
    print("    ⚙️  CONFIGURACIÓN DE IMPRESORAS, TIPOGRAFÍA, TAMAÑOS Y RESPALDOS ⚙️")
    print("="*80)
    
    # Listar impresoras instaladas en Windows
    installed_list = []
    try:
        import win32print
        flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
        installed_list = [p[2] for p in win32print.EnumPrinters(flags)]
        if installed_list:
            print("🖨️  Impresoras detectadas en este equipo Windows:")
            for p in installed_list:
                print(f"   • {p}")
            print("")
    except Exception:
        pass

    print("💡 Presiona [ENTER] en cada opción para aceptar los valores recomendados:\n")
    
    # 1. Impresoras por área
    new_map = {}
    new_sizes = {}
    for area in ["cuentas", "cocina", "barra"]:
        default_name = current_config["PRINTER_MAP"].get(area, area.upper())
        if installed_list and not any(p.upper() == default_name.upper() for p in installed_list):
            # Sugerir la que coincida por nombre o la primera instalada
            matched = [p for p in installed_list if area.lower() in p.lower()]
            if matched:
                default_name = matched[0]
            elif installed_list:
                default_name = installed_list[0]

        name = input(f"➤ Impresora Windows para '{area.upper()}' (Enter para '{default_name}'): ").strip()
        new_map[area] = name if name else default_name
        
        default_paper = current_config["PRINTER_PAPER_SIZES"].get(area, "80mm")
        size_in = input(f"   ¿Ancho de papel para '{area}'? (Enter para '{default_paper}', o ingresa '58' o '80'): ").strip()
        if size_in == "58" or size_in == "58mm":
            new_sizes[area] = "58mm"
        elif size_in == "80" or size_in == "80mm":
            new_sizes[area] = "80mm"
        else:
            new_sizes[area] = default_paper
            
        print(f"   ↳ Asignado: '{new_map[area]}' ({new_sizes[area]})\n")

    # 2. Tipografía y Tamaños de Letra para Cuentas / Cobro (GDI)
    print("--- 🎨 CONFIGURACIÓN DE CUENTAS / COBRO (Modo GDI con Logotipo) ---")
    print("   ↳ Nota: Las comandas de cocina y barra se imprimen en ESC/POS directo con letra grande por hardware.")
    
    default_font = current_config.get("FONT_NAME", "Arial")
    font_input = input(f"➤ Tipografía para cuentas (Enter para '{default_font}'): ").strip()
    new_font = font_input if font_input else default_font
    
    # Encabezados
    def_header_pt = current_config.get("HEADER_FONT_SIZE_PT", 18.0)
    in_header = input(f"➤ Tamaño Encabezados / Títulos de cuenta (Enter para '{def_header_pt} pt'): ").strip()
    try:
        new_header_pt = float(in_header) if in_header else def_header_pt
    except Exception:
        new_header_pt = def_header_pt
        
    # Platillos / Items de la cuenta
    def_item_pt = current_config.get("ITEM_FONT_SIZE_PT", 14.0)
    in_item = input(f"➤ Tamaño Platillos en la cuenta (Enter para '{def_item_pt} pt'): ").strip()
    try:
        new_item_pt = float(in_item) if in_item else def_item_pt
    except Exception:
        new_item_pt = def_item_pt

    # Totales
    def_total_pt = current_config.get("TOTAL_FONT_SIZE_PT", 16.0)
    in_total = input(f"➤ Tamaño Totales / Subtotales (Enter para '{def_total_pt} pt'): ").strip()
    try:
        new_total_pt = float(in_total) if in_total else def_total_pt
    except Exception:
        new_total_pt = def_total_pt

    # Base general
    def_base_pt = current_config.get("FONT_SIZE_PT", 12.0)
    in_base = input(f"➤ Tamaño Letra Base general (Enter para '{def_base_pt} pt'): ").strip()
    try:
        new_base_pt = float(in_base) if in_base else def_base_pt
    except Exception:
        new_base_pt = def_base_pt

    print(f"   ↳ Tipografía: '{new_font}' | Encabezado: {new_header_pt}pt | Platillos: {new_item_pt}pt | Totales: {new_total_pt}pt\n")

    # 3. Logotipo y Respaldos
    print("--- 📁 RUTAS DE LOGOTIPO Y RESPALDOS LOCALES ---")
    default_logo = current_config.get("LOGO_PATH", "C:\\buzon\\logo.jpg")
    logo_input = input(f"➤ Ruta física del logotipo (.jpg/.png) (Enter para '{default_logo}'): ").strip()
    new_logo = logo_input if logo_input else default_logo

    default_backup = current_config.get("BACKUP_FOLDER", "C:\\buzon\\respaldos")
    backup_input = input(f"➤ Carpeta para respaldos de turnos y ventas (Enter para '{default_backup}'): ").strip()
    new_backup = backup_input if backup_input else default_backup

    config_payload = {
        "_COMENTARIO_MODO": "PRINT_MODE define la operacion: 'hybrid' (Comandas en ESC/POS rapido y Cuentas en GDI con logo), 'raw' (todo en ESC/POS) o 'gdi' (todo en GDI).",
        "PRINT_MODE": "hybrid",
        "PRINTER_MAP": new_map,
        "PRINTER_PAPER_SIZES": new_sizes,
        "_SECCION_CUENTAS_Y_TICKETS_COBRO_GDI": "=== PARAMETROS PARA CUENTAS / COBRO (Modo GDI Vectorial con Logo) ===",
        "LOGO_PATH": new_logo,
        "FONT_NAME": new_font,
        "HEADER_FONT_SIZE_PT": new_header_pt,
        "ITEM_FONT_SIZE_PT": new_item_pt,
        "TOTAL_FONT_SIZE_PT": new_total_pt,
        "FONT_SIZE_PT": new_base_pt,
        "MARGIN_LEFT_PX": current_config.get("MARGIN_LEFT_PX", 10),
        "MARGIN_RIGHT_PX": current_config.get("MARGIN_RIGHT_PX", 25),
        "LINE_SPACING": current_config.get("LINE_SPACING", 4),
        "SHOW_DIVIDER": current_config.get("SHOW_DIVIDER", True),
        "_SECCION_COMANDAS_COCINA_BARRA_ESCPOS": "=== PARAMETROS PARA COMANDAS DE COCINA Y BARRA (Modo ESC/POS Nativo Rapido) ===",
        "COMANDAS_MODO": "ESC/POS",
        "COMANDAS_TAMANO_ENCABEZADO": "DOBLE_ALTO_Y_ANCHO",
        "COMANDAS_TAMANO_PLATILLOS": "DOBLE_ALTO_Y_NEGRITA",
        "COMANDAS_NOTAS_RESALTADAS": True,
        "_SECCION_RESPALDOS_Y_SISTEMA": "=== RUTAS Y RESPALDOS LOCALES ===",
        "BACKUP_FOLDER": new_backup,
        "ENVIRONMENT": env_mode,
        "DEBUG_VERBOSE": (env_mode == "testing"),
        "DB_PATH": current_config.get("DB_PATH", "restaurant.db"),
        "LOG_FILE": current_config.get("LOG_FILE", "sentinel_printer.log"),
        "POLL_INTERVAL_SECONDS": current_config.get("POLL_INTERVAL_SECONDS", 2),
        "DEDUP_TTL_SECONDS": current_config.get("DEDUP_TTL_SECONDS", 10),
        "ERROR_CODES": {
            "PRINTER_OFFLINE": "La impresora esta apagada, desconectada o fuera de linea.",
            "PRINTER_PAPER_OUT": "La impresora no tiene papel.",
            "PRINTER_DOOR_OPEN": "La tapa de la impresora esta abierta.",
            "PRINTER_PAPER_JAM": "Hay un atasco de papel en la impresora.",
            "PRINTER_NOT_FOUND": "No se encontro la impresora especificada en el sistema Windows.",
            "INVALID_PAYLOAD": "El formato JSON de impresion es invalido o esta malformado."
        }
    }
    
    # Guardar en target_dir y en las rutas raíz
    save_targets = [
        config_file,
        os.path.join(os.path.dirname(os.path.dirname(target_dir)), "printer_config.json"),
        os.path.join(os.path.dirname(target_dir), "printer_config.json")
    ]
    for st in save_targets:
        try:
            os.makedirs(os.path.dirname(st), exist_ok=True)
            with open(st, "w", encoding="utf-8") as f:
                json.dump(config_payload, f, indent=4, ensure_ascii=False)
        except Exception:
            pass
            
    print(f"✅ [OK] Configuración guardada exitosamente en: {config_file}\n")

def purge_all_cocinet_services():
    """Busca, detiene y elimina TODOS los servicios de Windows anteriores o duplicados que contengan 'Cocinet' y libera handles bloqueados (servicios fantasma)."""
    print("\n" + "="*80)
    print("🧹 [PURGA TOTAL] Eliminando servicios duplicados y liberando bloqueos de 'Cocinet'...")
    print("="*80)
    
    # 1. Cerrar procesos que bloquean el SCM (pythonservice.exe y mmc.exe / Consola de Servicios)
    # Esto soluciona de raíz el error 'Servicio marcado para eliminación' (Servicio Fantasma)
    run_command("taskkill /F /IM pythonservice.exe", "Cierre de procesos pythonservice.exe", ignore_error=True)
    run_command("taskkill /F /IM mmc.exe", "Cierre de Consola de Servicios de Windows (mmc.exe)", ignore_error=True)
    time.sleep(1.0)
    
    # 2. Descubrir TODOS los nombres de servicios en Windows que tengan 'Cocinet' en su nombre o DisplayName
    known_services = [
        "CocinetPrinterSentinel",
        "CocinetSentinel",
        "CocinetPrinterService",
        "CocinetPrintSentinel",
        "CocinetPrinter"
    ]
    
    try:
        ps_cmd = 'powershell -Command "Get-Service *Cocinet* | Select-Object -ExpandProperty Name"'
        res = subprocess.run(ps_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, shell=True, timeout=10)
        found = [line.strip() for line in res.stdout.splitlines() if line.strip()]
        for s in found:
            if s and s not in known_services:
                known_services.append(s)
    except Exception:
        pass

    # 3. Detener, eliminar y borrar clave de registro HKLM para cada servicio hallado
    for s_name in known_services:
        print(f"  🗑️ Limpiando servicio previo/fantasma: '{s_name}'...")
        run_command(f'sc stop "{s_name}"', f"Detener {s_name}", ignore_error=True)
        run_command(f'sc delete "{s_name}"', f"Eliminar {s_name}", ignore_error=True)
        run_command(f'reg delete "HKLM\\SYSTEM\\CurrentControlSet\\Services\\{s_name}" /f', f"Purga de registro HKLM para {s_name}", ignore_error=True)

    # 4. Asegurar que pythonservice.exe no haya quedado vivo
    run_command("taskkill /F /IM pythonservice.exe", "Limpieza final de pythonservice.exe", ignore_error=True)
    time.sleep(2.0)
    print("✅ [PURGA OK] Registro de servicios purgado y liberado correctamente.\n")

def main():
    parser = argparse.ArgumentParser(description="Instalador del Servicio Sentinela de Impresión")
    parser.add_argument("--env", choices=["production", "testing"], default="production", help="Ambiente de ejecucion")
    args, unknown = parser.parse_known_args()
    env_mode = args.env

    print_banner()

    # 1. Asegurar elevación de privilegios de Administrador
    if not is_admin():
        if not elevate_privileges():
            print("🛑 [PASO 1 FALLADO] El script REQUIERE ejecutarse con permisos de Administrador para instalar servicios.")
            print("💡 Sugerencia: Haz clic derecho sobre el instalador y selecciona 'Ejecutar como Administrador'.")
            input("\nPresiona Enter para salir...")
            sys.exit(1)
        sys.exit(0)
    else:
        print("🔓 [PASO 1 OK] Permisos de Administrador detectados y validados.")

    # 2. Localizar archivo sentinel_printer.py
    sentinel_path = check_sentinel_file()
    if not sentinel_path:
        print(f"🛑 [PASO 2 FALLADO] No se encontró el archivo '{SENTINEL_SCRIPT}' en la carpeta actual.")
        print("💡 Sugerencia: Asegúrate de extraer este instalador en el mismo directorio donde está el sentinela.")
        input("\nPresiona Enter para salir...")
        sys.exit(1)
    else:
        print(f"📂 [PASO 2 OK] Archivo del Sentinela localizado en: {sentinel_path}")

    # Cambiar al directorio del script para evitar fallos de rutas relativas
    os.chdir(os.path.dirname(sentinel_path))

    # 3. Purga completa de servicios legacy y fantasma de Cocinet
    purge_all_cocinet_services()

    # 5. Instalar/Actualizar Dependencias del Sistema
    print("📦 [PROCESANDO] Instalando y actualizando librerías de Python requeridas...")
    deps = ["pywin32", "Flask", "flask-cors", "flask-sock", "simple-websocket", "pillow"]
    for dep in deps:
        if not run_command(f'"{sys.executable}" -m pip install --upgrade {dep}', f"Instalar/Actualizar paquete '{dep}'"):
            print(f"🛑 [PASO 5 FALLADO] No se pudo instalar la dependencia crítica: {dep}")
            print("💡 Sugerencia: Revisa tu conexión a Internet y asegúrate de que 'pip' esté en tu PATH.")
            input("\nPresiona Enter para salir...")
            sys.exit(1)
    
    # 6. Ejecutar script de post-instalación de pywin32 para registrar DLLs en System32
    print("⚙️ [PROCESANDO] Registrando variables del sistema para servicios de Python en Windows...")
    try:
        import shutil
        sys32_path = os.environ.get("SystemRoot", r"C:\Windows") + r"\System32"
        pywin32_sys32 = os.path.join(sys.prefix, "Lib", "site-packages", "pywin32_system32")
        if os.path.exists(pywin32_sys32):
            for f in os.listdir(pywin32_sys32):
                if f.lower().endswith(".dll"):
                    src = os.path.join(pywin32_sys32, f)
                    try:
                        shutil.copy2(src, os.path.join(sys32_path, f))
                        shutil.copy2(src, os.path.join(sys.prefix, f))
                    except Exception:
                        pass
    except Exception:
        pass

    post_install_cmd = f'"{sys.executable}" -c "import os, sys; print(os.path.join(sys.prefix, \'Scripts\', \'pywin32_postinstall.py\'))"'
    try:
        post_path = subprocess.check_output(post_install_cmd, shell=True, text=True).strip()
        if os.path.exists(post_path):
            run_command(f'"{sys.executable}" "{post_path}" -install', "Ejecutar post-instalación de pywin32", ignore_error=True)
        else:
            # Buscar en el entorno virtual si aplica
            alt_path = os.path.join(sys.prefix, "Scripts", "pywin32_postinstall.py")
            if os.path.exists(alt_path):
                run_command(f'"{sys.executable}" "{alt_path}" -install', "Ejecutar post-instalación de pywin32 alternativo", ignore_error=True)
    except Exception as e:
        print(f"⚠️ [AVISO] No se pudo registrar pywin32_postinstall de forma automatizada ({e}). Continuando de todos modos...")

    # 6.5. Configuración de Impresoras y Tamaños de Papel (58mm / 80mm)
    configure_printer_sizes(os.path.dirname(sentinel_path), env_mode=env_mode)

    # 7. Instalar el nuevo servicio de Windows
    print("🔌 [PROCESANDO] Instalando el renovado servicio de Windows del Sentinela v3.6.0...")
    # Instalamos con inicio retrasado o automático para que el spooler de Windows esté listo al iniciar
    if not run_command(f'"{sys.executable}" "{SENTINEL_SCRIPT}" install', "Registrar Servicio de Windows"):
        print("🛑 [PASO 7 FALLADO] Error al registrar el servicio de Windows.")
        print("💡 Sugerencia: Asegúrate de que no haya procesos de Python fantasma bloqueando y de que ejecutas como Administrador.")
        input("\nPresiona Enter para salir...")
        sys.exit(1)

    # Configurar el servicio para que se inicie de forma automática en Windows y se reinicie automáticamente ante fallas en 3 segundos
    run_command(f'sc config {SERVICE_NAME} start= auto', "Configurar servicio en modo automático", ignore_error=True)
    run_command(f'sc failure {SERVICE_NAME} reset= 0 actions= restart/3000/restart/3000/restart/3000', "Configurar opciones de recuperación de servicio (Reinicio automático en 3s)", ignore_error=True)

    # 8. Iniciar el servicio de Windows
    print("⚡ [PROCESANDO] Inicializando el servicio en segundo plano de Windows...")
    if not run_command(f'"{sys.executable}" "{SENTINEL_SCRIPT}" start', "Iniciar Servicio de Windows"):
        # Intentar forzar con SC
        if not run_command(f'sc start {SERVICE_NAME}', "Iniciar Servicio de Windows con SCM"):
            print("🛑 [PASO 8 FALLADO] No se pudo iniciar el servicio de Windows recién instalado.")
            print("💡 Sugerencia: Revisa los logs de Windows Event Viewer o ejecuta 'python sentinel_printer.py' en consola para ver errores.")
            input("\nPresiona Enter para salir...")
            sys.exit(1)

    # 9. Verificación final de salud del servicio HTTP
    print("🎯 [PROCESANDO] Realizando pruebas de conexión finales...")
    verify_service_status()

    print("🎈 ¡INSTALACIÓN Y ACTUALIZACIÓN v7.0.0-PRO FINALIZADA CON ÉXITO! 🎈")
    print("================================================================================")
    print("  VERSIÓN INSTALADA: v7.0.0-PRO (Sentinela de Impresión Cocinet)")
    print("")
    print("  PROPÓSITO Y USO DEL SERVICIO:")
    print("  • Servicio de fondo (Puerto 3010) para recepción de comanda/cuenta desde Cocinet.")
    print("  • Impresión térmica vectorizada GDI y ESC/POS en papel 58mm y 80mm por área.")
    print("  • Servidor de alta disponibilidad para comandas de Cocina, Cuentas y Barra.")
    print("")
    print("  NOVEDADES Y ACTUALIZACIONES APLICADAS (v7.0.0-PRO):")
    print("  • 🛡️ Registro automático de diagnósticos de caídas en 'sentinel_crash.log'.")
    print("  • 🔄 Reconexión automática en puerto 3010 y tolerancia a fallos de red.")
    print("  • ⚡ Encolado de contingencia en SQLite si la impresora está desconectada.")
    print("  • 🖨️ Formateo limpio de 1 línea por producto con montos y sumas exactos.")
    print("================================================================================\n")
    input("Presiona Enter para finalizar el instalador... 🌟")

if __name__ == "__main__":
    main()